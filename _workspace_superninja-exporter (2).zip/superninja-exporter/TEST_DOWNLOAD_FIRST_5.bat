@echo off
REM ============================================================
REM  SuperNinja Workspace Downloader - TEST RUN (first 5 tasks)
REM  Downloads every workspace file (incl. subdirectories) for
REM  the first 5 tasks, into each task's folder.
REM ============================================================
echo.
echo === Workspace Downloader: TEST (first 5 tasks) ===
echo.
echo BEFORE running this:
echo   1. Double-click  0_START_CHROME.bat
echo   2. In the Chrome window that opens, log into SuperNinja
echo      and make sure you can see your tasks.
echo   3. Leave that Chrome window OPEN, then continue here.
echo.
pause

if not exist venv\Scripts\activate.bat (
    echo ERROR: Setup has not been run yet.
    echo Please double-click  1_SETUP.bat  first.
    echo.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
python download_workspace.py --limit 5

echo.
echo Test finished. Check the SuperNinja_Export folder - each task folder
echo should now contain a  workspace\  subfolder with the downloaded files.
echo If it looks good, run  RUN_DOWNLOAD_ALL.bat  for all tasks.
echo.
pause
