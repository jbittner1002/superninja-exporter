#!/usr/bin/env python3
"""
SuperNinja Chat Exporter
------------------------
Runs locally on YOUR computer, using YOUR logged-in browser session, to export
your own SuperNinja tasks/chats into organized folders on disk.

It does NOT bypass any authentication: you log in manually the first time in a
real browser window, and the session is saved so subsequent runs are automatic.

Usage:
    python export_chats.py            # normal run (uses saved login, else prompts)
    python export_chats.py --login    # force a fresh manual login
    python export_chats.py --limit 5  # only export the first 5 tasks (for testing)

See README for step-by-step Windows instructions.
"""

import argparse
import json
import re
import sys
import time
from datetime import datetime
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
except ImportError:
    print("ERROR: Playwright is not installed.")
    print("Run:  pip install -r requirements.txt")
    print("Then: python -m playwright install chromium")
    sys.exit(1)


HERE = Path(__file__).resolve().parent
CONFIG_PATH = HERE / "config.json"
SESSION_PATH = HERE / "session_state.json"
PROFILE_DIR = HERE / "chrome_profile"  # persistent Chrome profile (keeps you logged in)


# ---------------------------------------------------------------------------
# Silence a harmless-but-noisy Playwright internal bug.
#
# SuperNinja constantly swaps out iframes as it re-renders the virtualized
# chat. Playwright's background event listener for "frame detached" sometimes
# tries to remove a frame it has already removed, raising:
#     ValueError: list.remove(x): x not in list
# in playwright/_impl/_page.py -> _on_frame_detached. This is purely cosmetic
# (the export still works), but it spams the console and can, in rare cases,
# interrupt a wait_for_timeout call. We patch the internal method to ignore
# that specific error.
# ---------------------------------------------------------------------------
def _patch_playwright_frame_detach_noise():
    try:
        from playwright._impl import _page as _pw_page

        _orig = _pw_page.Page._on_frame_detached

        def _safe_on_frame_detached(self, frame):
            try:
                _orig(self, frame)
            except ValueError:
                # frame already removed from internal list -> ignore
                pass
            except Exception:
                pass

        _pw_page.Page._on_frame_detached = _safe_on_frame_detached
    except Exception:
        # If Playwright internals change, just skip the patch silently.
        pass


_patch_playwright_frame_detach_noise()


def connect_over_cdp(p, cfg):
    """Attach to an already-running Chrome started by 0_START_CHROME.bat.

    This is the reliable way to avoid Google's "This browser or app may not be
    secure" block: the browser is launched WITHOUT automation flags (by the
    .bat file), and we merely connect to it. Returns (browser, context).
    """
    port = cfg.get("cdp_port", 9222)
    endpoint = f"http://localhost:{port}"
    try:
        browser = p.chromium.connect_over_cdp(endpoint)
    except Exception as e:
        print("\n" + "=" * 70)
        print("COULD NOT CONNECT TO CHROME")
        print("=" * 70)
        print(f"Tried to attach to Chrome at {endpoint} but failed.")
        print("Make sure you FIRST double-clicked  0_START_CHROME.bat  and that")
        print("the Chrome window it opened is still OPEN and logged in.")
        print(f"(Underlying error: {e})")
        print("=" * 70 + "\n")
        raise
    # Reuse the existing context/page from your real Chrome session.
    if browser.contexts:
        context = browser.contexts[0]
    else:
        context = browser.new_context()
    return browser, context


def launch_browser(p, cfg, headless):
    """Launch or connect to the browser according to config.

    Returns (browser_or_none, context). Callers close whichever is not None.
    """
    if cfg.get("connect_mode") == "cdp":
        return connect_over_cdp(p, cfg)

    channel = cfg.get("browser_channel")  # e.g. "chrome", "msedge", or None
    launch_kwargs = {"headless": headless}
    if channel:
        launch_kwargs["channel"] = channel

    if cfg.get("use_persistent_profile", False):
        PROFILE_DIR.mkdir(parents=True, exist_ok=True)
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(PROFILE_DIR),
            headless=headless,
            channel=channel if channel else None,
        )
        return None, context

    browser = p.chromium.launch(**launch_kwargs)
    if SESSION_PATH.exists():
        context = browser.new_context(storage_state=str(SESSION_PATH))
    else:
        context = browser.new_context()
    return browser, context


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def slugify(text, max_len=80):
    """Turn an arbitrary string into a safe folder/file name for Windows."""
    if not text:
        text = "untitled"
    text = text.strip()
    # Remove characters illegal on Windows: \ / : * ? " < > |
    text = re.sub(r'[\\/:*?"<>|]', "", text)
    text = re.sub(r"\s+", "_", text)
    text = re.sub(r"[^A-Za-z0-9._\-]", "", text)
    text = text.strip("._-")
    if not text:
        text = "untitled"
    return text[:max_len]


def unique_dir(base: Path, name: str) -> Path:
    """Return a directory path that does not collide with an existing one."""
    candidate = base / name
    i = 2
    while candidate.exists():
        candidate = base / f"{name}_{i}"
        i += 1
    return candidate


# ---------------------------------------------------------------------------
# Login / session handling
# ---------------------------------------------------------------------------

def do_manual_login(cfg):
    """Open a visible browser (your real Chrome), let the user log in, save session."""
    print("\n" + "=" * 70)
    print("MANUAL LOGIN")
    print("=" * 70)
    which = "your installed Google Chrome" if cfg.get("browser_channel") == "chrome" else "a browser"
    print(f"{which} window will open. Please:")
    print("  1. Log into your SuperNinja account as you normally would")
    print("     (including 'Sign in with Google' if that's what you use).")
    print("  2. Make sure you can see your list of tasks/chats.")
    print("  3. Return to THIS window and press ENTER.")
    print("=" * 70 + "\n")

    with sync_playwright() as p:
        browser, context = launch_browser(p, cfg, headless=False)
        page = context.new_page()
        page.goto(cfg["base_url"], wait_until="domcontentloaded")
        input(">>> After you have logged in and can see your tasks, press ENTER here... ")
        # Save storage state too (harmless, useful as a backup even with a profile).
        try:
            context.storage_state(path=str(SESSION_PATH))
        except Exception:
            pass
        (browser or context).close()

    if cfg.get("use_persistent_profile", False):
        print(f"Login saved in the Chrome profile folder. Future runs stay logged in.\n")
    else:
        print(f"Session saved to {SESSION_PATH.name}. Future runs will reuse it.\n")


# ---------------------------------------------------------------------------
# Discovery of task links
# ---------------------------------------------------------------------------

def discover_task_links(page, cfg):
    """Collect unique task/chat URLs from the sidebar/home page."""
    print("Discovering your tasks... (scrolling the task list)")

    include = cfg["selectors"].get("task_link_include_paths", [])
    exclude = cfg["selectors"].get("task_link_exclude_paths", [])

    def is_wanted(href):
        low = href.lower()
        if exclude and any(x.lower() in low for x in exclude):
            return False
        if include:
            return any(inc.lower() in low for inc in include)
        return True

    # Scroll the whole page AND any scrollable sidebar to trigger lazy loading
    # of the full task list. We scroll the sidebar element to its bottom too.
    def scroll_everything():
        page.mouse.wheel(0, 6000)
        page.wait_for_timeout(cfg.get("scroll_pause_ms", 800))
        try:
            page.evaluate(
                """() => {
                    const nodes = document.querySelectorAll('nav, aside, [class*="sidebar"], [class*="Sidebar"], [class*="scroll"]');
                    nodes.forEach(n => { n.scrollTop = n.scrollHeight; });
                }"""
            )
        except Exception:
            pass
        page.wait_for_timeout(300)

    found = {}
    stable_rounds = 0
    for _ in range(cfg.get("max_scroll_rounds", 40)):
        scroll_everything()

        before = len(found)
        for selector in cfg["selectors"]["task_list_links"]:
            try:
                handles = page.query_selector_all(selector)
            except Exception:
                continue
            for h in handles:
                try:
                    href = h.get_attribute("href")
                    if not href:
                        # Some items are clickable divs; try a child <a>.
                        a = h.query_selector("a[href]")
                        href = a.get_attribute("href") if a else None
                    if not href:
                        continue
                    if href.startswith("/"):
                        href = cfg["base_url"].rstrip("/") + href
                    if cfg["base_url"] not in href:
                        continue
                    if not is_wanted(href):
                        continue
                    label = (h.inner_text() or "").strip().split("\n")[0]
                    if href not in found:
                        found[href] = label
                except Exception:
                    continue

        # Stop early once the count stops growing for a few rounds.
        if len(found) == before:
            stable_rounds += 1
            if stable_rounds >= 3 and len(found) > 0:
                break
        else:
            stable_rounds = 0

    links = [{"url": u, "label": lbl} for u, lbl in found.items()]
    print(f"Found {len(links)} task link(s).")
    return links


# ---------------------------------------------------------------------------
# Extraction of a single chat
# ---------------------------------------------------------------------------

def extract_by_selection(page, cfg, scroller_state, set_scroll_top, pause):
    """Replicate the manual 'select from top to bottom and copy' method.

    Programmatically extends a DOM Selection from the first rendered message
    downward, scrolling in small steps so virtualized messages render into the
    selection. Returns the full selected text.
    """
    step = cfg.get("select_scroll_step_px", 300)
    max_steps = cfg.get("select_max_steps", 4000)

    st = scroller_state()
    if not st:
        return ""

    # Helper: click SuperNinja's floating "jump to top" button (circular button
    # with an up-arrow-to-bar icon). This is far faster than polling scrollTop=0,
    # because the app instantly jumps to the top AND triggers a history load.
    # Returns True if a button was found and clicked.
    # The exact "jump to top" button on SuperNinja is a round 40x40 button
    # holding a Phosphor "arrow-line-up" icon. Its SVG <path d="..."> starts
    # with this unique signature (arrow head + top bar). We match on it directly.
    click_top_btn_js = """
    () => {
        const TOP_SIG = 'M205.66,138.34';   // arrow-line-up (jump to TOP)
        // 1) Exact icon match: find a button whose SVG path is the up-arrow-to-bar.
        const paths = Array.from(document.querySelectorAll('button svg path, [role="button"] svg path'));
        for (const p of paths) {
            const d = p.getAttribute('d') || '';
            if (d.replace(/\\s/g,'').startsWith(TOP_SIG)) {
                const btn = p.closest('button, [role="button"]');
                if (btn) { btn.click(); return 'icon'; }
            }
        }
        // 2) Label fallback.
        const byLabel = Array.from(document.querySelectorAll(
            'button, [role="button"], a'
        )).find(b => {
            const s = ((b.getAttribute('aria-label')||'') + ' ' +
                       (b.getAttribute('title')||'')).toLowerCase();
            return /scroll to top|go to top|jump to top|to top|top of/.test(s);
        });
        if (byLabel) { byLabel.click(); return 'label'; }
        return '';
    }
    """

    def click_jump_to_top():
        try:
            return bool(page.evaluate(click_top_btn_js))
        except Exception:
            return False

    # Probe once so we can log which method the top-jump used.
    _first = click_jump_to_top()
    if _first:
        print("      [select] found + clicked in-app 'jump to top' button (fast).")
    else:
        print("      [select] no jump-to-top button found; using scroll (slower).")

    # MEMORY-SAFE mode: on very large threads, forcing the WHOLE conversation
    # into the DOM at once (the old "jump to top until stable" approach) can
    # exhaust Chrome's memory and trigger the "Aw, Snap / refresh" page. When
    # enabled (default), we instead harvest history INCREMENTALLY as it loads
    # near the top, capturing text+html each round, so we never depend on the
    # entire thread being rendered simultaneously. As we later sweep DOWN, the
    # app's virtualizer unloads the off-screen top nodes, keeping DOM size (and
    # memory) bounded.
    memory_safe = cfg.get("memory_safe", True)

    def js_heap_mb():
        try:
            v = page.evaluate("() => (performance.memory ? performance.memory.usedJSHeapSize : 0)")
            return round((v or 0) / (1024 * 1024))
        except Exception:
            return 0

    # NOTE: The actual "load older history near the top" loop runs a bit lower,
    # AFTER grab_here() is defined, so that in memory-safe mode we can harvest
    # each chunk of history as it appears (rather than requiring the entire
    # thread to be resident in the DOM at once).

    # 2) Sweep DOWN through the whole thread, harvesting the rendered text at
    #    every step. We do NOT rely on sel.extend() (it breaks across
    #    virtualized boundaries, which is why long threads came out short).
    #    Instead we grab the innerText of every rendered message chunk and
    #    accumulate it, keyed by vertical position so the order stays correct.
    #
    #    We STOP only when BOTH are true for several consecutive steps:
    #      - we're at the bottom (scrollTop can't go further), AND
    #      - the app is not showing a "loading..." spinner, AND
    #      - no new text has appeared.
    #    This matches your rule: "when it stops saying loading... and it's at
    #    the bottom."
    print("      [select] sweeping down and harvesting the full thread...")

    # JS: capture every rendered message chunk with an absolute Y position.
    # We grab BOTH user and assistant message blocks (by the configured
    # selectors) so nothing is missed, plus a generic fallback to the
    # container's own text if selectors match nothing.
    user_sels = cfg["selectors"].get("message_user_selectors", [])
    asst_sels = cfg["selectors"].get("message_assistant_selectors", [])
    grab_js = """
    (sel) => {
        const scroller = window.__njScroller || document.body;
        const baseTop = scroller.getBoundingClientRect().top;
        const baseScroll = scroller.scrollTop || 0;
        const q = (sel.user.concat(sel.asst)).join(',');
        let nodes = q ? Array.from(scroller.querySelectorAll(q)) : [];
        // Keep only outermost matches (no nested duplicates).
        nodes = nodes.filter(n => !nodes.some(o => o !== n && o.contains(n)));
        const out = nodes.map(n => {
            let role = 'assistant';
            if (sel.user.length && n.matches(sel.user.join(','))) role = 'user';
            const rect = n.getBoundingClientRect();
            const absY = Math.round((rect.top - baseTop) + baseScroll);
            return {
                role,
                text: (n.innerText || '').trim(),
                html: (n.innerHTML || ''),   // keep the rendered formatting
                y: absY
            };
        }).filter(m => m.text.length > 1);
        return out;
    }
    """

    collected = {}   # key -> {role, text, html, y}

    def grab_here():
        try:
            items = page.evaluate(grab_js, {"user": user_sels, "asst": asst_sels})
        except Exception:
            items = []
        for it in items:
            txt = (it.get("text") or "").strip()
            txt = re.sub(
                r"\s*(Today|Yesterday|[A-Z][a-z]{2}\s+\d{1,2}),?\s+\d{1,2}:\d{2}\s*(AM|PM)?\s*$",
                "", txt,
            ).strip()
            if len(txt) < 2:
                continue
            html = it.get("html", "") or ""
            key = (it.get("role", "?"), txt[:220])
            if key in collected:
                collected[key]["y"] = it.get("y", collected[key]["y"])
                # Keep the LONGEST html we've seen (last message may still be
                # streaming, so later grabs are more complete).
                if len(html) > len(collected[key].get("html", "")):
                    collected[key]["html"] = html
                    collected[key]["text"] = txt
            else:
                collected[key] = {"role": it.get("role", "assistant"),
                                  "text": txt, "html": html,
                                  "y": it.get("y", 0)}

    # 1) Load older history. SuperNinja lazily loads older messages when you go
    #    to the top and PREPENDS them (scrollHeight grows). We keep jumping to
    #    the top until the height stops growing. In memory-safe mode we HARVEST
    #    at each round (so history is captured as it appears) and we do NOT
    #    require the whole thing to stay resident in the DOM.
    print("      [select] loading history near the top"
          + (" (memory-safe, harvesting as we go)..." if memory_safe else "..."))
    last_sh = -1
    stable = 0
    NEED_STABLE = 6            # require 6 stable checks (history truly done)
    top_pause = max(pause, 900)

    for r in range(cfg.get("top_load_max_rounds", 400)):
        # Prefer the app's own "jump to top" button; fall back to scrollTop=0.
        clicked = click_jump_to_top()
        if not clicked:
            set_scroll_top(0)
        page.wait_for_timeout(top_pause)
        # Harvest whatever history is currently rendered near the top so we
        # don't need it to stay in the DOM (this is what bounds memory).
        if memory_safe:
            grab_here()
            if r > 0 and r % cfg.get("gc_every_steps", 25) == 0:
                try:
                    page.evaluate("() => { try { if (window.gc) window.gc(); } catch(e){} }")
                except Exception:
                    pass
        st = scroller_state()
        if not st:
            break
        sh = st["sh"]
        if r % 4 == 0:
            print(f"        [select] top-load check {r}: height={sh}, "
                  f"stable={stable}, heap={js_heap_mb()}MB")
        if sh <= last_sh + 5:
            stable += 1
            if stable >= NEED_STABLE:
                print("        [select] history fully loaded (height stable).")
                break
        else:
            stable = 0
        last_sh = sh

    set_scroll_top(0)
    page.wait_for_timeout(pause)
    grab_here()

    pos = 0
    prev_count = -1
    bottom_stable = 0
    # A "signature" of ALL captured text length, so we detect the LAST message
    # still growing (streaming) at the bottom, not just the message COUNT.
    prev_total_chars = -1

    # STOP RULE: once we're at the bottom, we wait patiently and only stop when
    # NEITHER the message count NOR the total captured text has changed for
    # BOTTOM_STABLE_CHECKS consecutive checks. SuperNinja can pause for several
    # seconds while loading/streaming the tail, so we are deliberately patient.
    BOTTOM_STABLE_CHECKS = cfg.get("bottom_stable_checks", 12)
    # Extra-long wait between checks while sitting at the bottom (ms), to give
    # the app time to finish loading/streaming the final section.
    bottom_pause = max(cfg.get("bottom_pause_ms", 1500), pause)
    # Absolute safety cap so we can never loop forever.
    STALL_GUARD = cfg.get("bottom_stall_guard", 30)
    stall_count = 0

    def total_chars():
        return sum(len(v["text"]) for v in collected.values())

    for i in range(max_steps):
        st = scroller_state()
        if not st:
            break
        max_top = st["sh"] - st["ch"]
        at_bottom = pos >= max_top - 3

        grab_here()
        cur_count = len(collected)
        cur_chars = total_chars()

        # Progress log every few steps.
        if i % 6 == 0:
            print(f"        [select] step {i}, {cur_count} messages, "
                  f"{cur_chars} chars, pos={pos}/{max_top}, bottom={at_bottom}, "
                  f"stable={bottom_stable}, heap={js_heap_mb()}MB")

        # Periodically hint the browser to release memory. As we scroll down,
        # the virtualizer drops off-screen (already-captured) top nodes; asking
        # for GC and clearing any lingering DOM selection helps keep Chrome from
        # ballooning on very long threads.
        if memory_safe and i > 0 and i % cfg.get("gc_every_steps", 25) == 0:
            try:
                page.evaluate(
                    """() => {
                        try { window.getSelection && window.getSelection().removeAllRanges(); } catch(e){}
                        try { if (window.gc) window.gc(); } catch(e){}
                    }"""
                )
            except Exception:
                pass

        if at_bottom:
            # Consider it "unchanged" only if BOTH count AND total text are the
            # same as last check (so a streaming last message keeps us waiting).
            unchanged = (cur_count == prev_count and cur_chars == prev_total_chars)
            if unchanged:
                bottom_stable += 1
                stall_count += 1
                if bottom_stable >= BOTTOM_STABLE_CHECKS:
                    print("        [select] bottom fully settled (count + text stable) -> stopping.")
                    break
                if stall_count >= STALL_GUARD:
                    print("        [select] bottom safety cap reached -> stopping.")
                    break
            else:
                # Something changed (new message OR last message grew) -> reset
                # and keep waiting patiently.
                bottom_stable = 0
                stall_count = 0
            prev_count = cur_count
            prev_total_chars = cur_chars
            # Sit at the bottom and wait longer for the tail to finish.
            set_scroll_top(max_top)
            page.wait_for_timeout(bottom_pause)
            continue

        # Otherwise keep stepping down.
        pos = min(pos + step, max_top)
        set_scroll_top(pos)
        page.wait_for_timeout(pause)

    # Final settle: sit at the very bottom a moment and grab once more so the
    # last (possibly streaming) message is captured in full.
    try:
        _st = scroller_state()
        set_scroll_top((_st["sh"] - _st["ch"]) if _st else 10 ** 8)
    except Exception:
        set_scroll_top(10 ** 8)
    page.wait_for_timeout(bottom_pause)
    grab_here()

    # Order by vertical position and stitch into one text blob.
    ordered = sorted(collected.values(), key=lambda m: m["y"])
    print(f"      [select] done: {len(ordered)} message blocks captured.")
    parts = [m["text"] for m in ordered]
    text = "\n\n".join(parts)
    # Also return the ordered blocks (role/text/html) so callers can build a
    # formatted HTML export that preserves bold, code, lists, links, etc.
    blocks = [{"role": m.get("role", "assistant"),
               "text": m.get("text", ""),
               "html": m.get("html", "")} for m in ordered]
    return text or "", blocks


def parse_selected_text(raw, cfg):
    """Turn the big selected-text blob into a list of messages.

    We can't perfectly know role boundaries from plain text, but SuperNinja user
    messages are short and often followed by a timestamp line. We split on
    timestamp markers and keep the flow. If uncertain, we keep the whole thing
    as ordered blocks. The raw_text is always saved too, so nothing is lost.
    """
    import re as _re
    # Normalize whitespace/newlines.
    lines = [ln.rstrip() for ln in raw.replace("\r\n", "\n").split("\n")]
    # Collapse 3+ blank lines to 2.
    cleaned = []
    blanks = 0
    for ln in lines:
        if ln.strip() == "":
            blanks += 1
            if blanks <= 2:
                cleaned.append("")
        else:
            blanks = 0
            cleaned.append(ln)
    text = "\n".join(cleaned).strip()

    # Split into blocks at timestamp lines like "Jun 18, 12:36 PM" / "Today, 06:12 PM".
    ts = _re.compile(
        r"^\s*(Today|Yesterday|[A-Z][a-z]{2}\s+\d{1,2}),?\s+\d{1,2}:\d{2}\s*(AM|PM)?\s*$"
    )
    blocks = []
    cur = []
    for ln in text.split("\n"):
        if ts.match(ln):
            # Timestamp closes the current block (usually a user message).
            block = "\n".join(cur).strip()
            if block:
                blocks.append({"role": "message", "text": block})
            cur = []
        else:
            cur.append(ln)
    tail = "\n".join(cur).strip()
    if tail:
        blocks.append({"role": "message", "text": tail})

    if not blocks:
        blocks = [{"role": "message", "text": text}]
    return blocks


def extract_chat(page, cfg, url, fallback_title=None):
    """Open a task URL, load the full conversation, and return structured data."""
    page.goto(url, wait_until="domcontentloaded")
    page.wait_for_timeout(2000)

    # Find the scrollable message container (largest scrollable element).
    def get_scroller_info():
        try:
            return page.evaluate(
                """() => {
                    let best = null;
                    document.querySelectorAll('*').forEach(e => {
                        if (e.scrollHeight > e.clientHeight + 50 && e.clientHeight > 200) {
                            if (!best || e.scrollHeight > best.sh) {
                                best = {sh: e.scrollHeight, ch: e.clientHeight};
                            }
                        }
                    });
                    return best;
                }"""
            )
        except Exception:
            return None

    scroll_prefs = cfg["selectors"].get("chat_scroll_container", [])

    # JS helpers to identify and control the chat scroll container. We keep a
    # handle to the SAME element across calls (window.__njScroller) so all our
    # scrolling acts on the real message list, not the sidebar.
    find_scroller_js = """
    (prefs) => {
        let el = null;
        for (const sel of prefs) {
            try {
                const c = document.querySelector(sel);
                if (c && c.scrollHeight > c.clientHeight + 50) { el = c; break; }
            } catch (e) {}
        }
        if (!el) {
            let best = null;
            document.querySelectorAll('*').forEach(e => {
                if (e.scrollHeight > e.clientHeight + 50 && e.clientHeight > 200) {
                    // Skip the left sidebar task list.
                    const cls = (typeof e.className === 'string' ? e.className : '');
                    if (cls.includes('TasksAndProjectsList')) return;
                    if (!best || e.scrollHeight > best.scrollHeight) best = e;
                }
            });
            el = best;
        }
        window.__njScroller = el;
        return el ? {sh: el.scrollHeight, ch: el.clientHeight, top: el.scrollTop} : null;
    }
    """

    def scroller_state():
        try:
            return page.evaluate(find_scroller_js, scroll_prefs)
        except Exception:
            return None

    def set_scroll_top(px):
        try:
            page.evaluate(
                """(px) => {
                    const el = window.__njScroller;
                    if (el) el.scrollTop = px;
                    else window.scrollTo(0, px);
                }""",
                px,
            )
        except Exception:
            pass

    def scroll_container_to(frac):
        st = scroller_state()
        if st:
            set_scroll_top(int(st["sh"] * frac))

    # STEP 1: Jump to the very TOP so lazy/virtualized history starts loading.
    scroll_container_to(0.0)
    page.wait_for_timeout(1200)

    # STEP 2: Incrementally scroll DOWN through the whole thread, collecting
    # message text as we go. Virtualized lists only keep on-screen nodes in the
    # DOM, so we must harvest at each step and deduplicate.
    collected = []           # ordered list of {role, text}
    seen_texts = set()
    text_to_item = {}        # maps text-key -> item, so we can update _y later
    user_sels = cfg["selectors"].get("message_user_selectors", [])
    asst_sels = cfg["selectors"].get("message_assistant_selectors", [])

    # Build one JS query that returns messages IN DOCUMENT ORDER, each tagged
    # with its role by matching the user/assistant selector groups. This keeps
    # the conversation flow correct (user, assistant, user, assistant, ...).
    # Returns each on-screen message with an ABSOLUTE vertical position within
    # the scroll container, so we can sort everything into true thread order
    # even though we harvest during both down and up scroll passes.
    order_js = """
    (sel) => {
        const userSel = sel.user.join(',');
        const asstSel = sel.asst.join(',');
        const scroller = window.__njScroller;
        const baseTop = scroller ? scroller.getBoundingClientRect().top : 0;
        const baseScroll = scroller ? scroller.scrollTop : window.scrollY;
        const nodes = Array.from(document.querySelectorAll(userSel + ',' + asstSel));
        const top = nodes.filter(n => !nodes.some(o => o !== n && o.contains(n)));
        return top.map(n => {
            let role = 'assistant';
            if (userSel && n.matches(userSel)) role = 'user';
            const rect = n.getBoundingClientRect();
            const absY = (rect.top - baseTop) + baseScroll;
            return { role, text: (n.innerText || '').trim(), y: Math.round(absY) };
        }).filter(m => m.text.length > 1);
    }
    """

    def harvest():
        try:
            items = page.evaluate(order_js, {"user": user_sels, "asst": asst_sels})
        except Exception:
            items = []
        for it in items:
            text = (it.get("text") or "").strip()
            # Strip a trailing UI timestamp like "Today, 06:12 PM" or
            # "Jun 18, 12:36 PM" that SuperNinja appends to user messages.
            text = re.sub(
                r"\s*(Today|Yesterday|[A-Z][a-z]{2}\s+\d{1,2}),?\s+\d{1,2}:\d{2}\s*(AM|PM)?\s*$",
                "",
                text,
            ).strip()
            if len(text) < 2:
                continue
            key = (it.get("role", "?"), text[:200])
            if key in seen_texts:
                # Update the position with the most recent measurement (after
                # any lazy history prepending, coordinates shift; the latest
                # consistent sweep gives the correct relative order).
                item = text_to_item.get(key)
                if item is not None:
                    item["_y"] = it.get("y", item.get("_y", 0))
                continue
            seen_texts.add(key)
            item = {
                "role": it.get("role", "unknown"),
                "text": text,
                "_y": it.get("y", 0),
            }
            collected.append(item)
            text_to_item[key] = item
        return bool(items)

    pause = cfg.get("scroll_pause_ms", 800)

    # Resolve the chat title EARLY so it's available for every extraction path.
    def resolve_title():
        t_val = None
        for tsel in cfg["selectors"].get("task_title", []):
            try:
                el = page.query_selector(tsel)
                if el:
                    t = (el.inner_text() or "").strip()
                    if t:
                        t_val = t.split("\n")[0]
                        break
            except Exception:
                continue
        generic = {"ninjatech ai", "superninja", "ninja", ""}
        if (not t_val) or t_val.strip().lower() in generic:
            if fallback_title and fallback_title.strip():
                t_val = fallback_title.strip()
            elif not t_val:
                t_val = page.title() or "untitled"
        if t_val.strip().lower() in generic:
            tail = url.rstrip("/").split("/")[-1][:8]
            t_val = f"chat_{tail}"
        return t_val

    title = resolve_title()

    # ------------------------------------------------------------------
    # SELECT-ALL METHOD (mirrors the manual trick that worked for the user):
    # jump to the top, then extend a text selection downward step-by-step while
    # scrolling, forcing every virtualized message to render and stay captured.
    # Finally read the full selected text from the clipboard/selection.
    # ------------------------------------------------------------------
    if cfg.get("extraction_method") == "select_all":
        result, blocks = extract_by_selection(
            page, cfg, scroller_state, set_scroll_top, pause
        )
        if result and len(result.strip()) > 40:
            messages = parse_selected_text(result, cfg)
            return {
                "url": url,
                "title": title,
                "scraped_at": datetime.now().isoformat(),
                "message_count": len(messages),
                "messages": messages,
                "raw_text": result,
                "html_blocks": blocks,   # role/text/html per message, in order
            }
        # else fall through to the scroll-harvest method below.
        print("      select-all returned little text; falling back to scroll-harvest.")

    st = scroller_state()
    if not st:
        # No scroll container found: fall back to window scrolling.
        for i in range(80):
            page.mouse.wheel(0, -500)
            page.wait_for_timeout(pause)
            harvest()
        for i in range(120):
            page.mouse.wheel(0, 500)
            page.wait_for_timeout(pause)
            harvest()
    else:
        viewport = max(int(st["ch"] * 0.6), 300)

        # ---- PHASE 1: Exhaustively load ALL older history at the TOP ----
        # SuperNinja loads older messages lazily when you scroll up and PREPENDS
        # them, which grows scrollHeight. We repeatedly jump to the top, wait for
        # more to load, and harvest, until the height stops growing (= real top).
        print("      loading full history (scrolling to top)...")
        last_sh = -1
        stable = 0
        for _round in range(400):  # hard safety cap
            set_scroll_top(0)
            page.wait_for_timeout(pause)
            harvest()
            if _round % 5 == 0:
                print(f"        ...{len(collected)} messages loaded so far")
            st = scroller_state()
            if not st:
                break
            sh = st["sh"]
            if sh <= last_sh + 5:
                stable += 1
                # Nudge down a little then back to top to trigger more loading.
                set_scroll_top(viewport)
                page.wait_for_timeout(300)
                set_scroll_top(0)
                page.wait_for_timeout(pause)
                harvest()
                st2 = scroller_state()
                if st2 and st2["sh"] > sh + 5:
                    stable = 0
                    last_sh = st2["sh"]
                    continue
                if stable >= 4:
                    break  # height truly stable -> reached the beginning
            else:
                stable = 0
            last_sh = sh

        # ---- PHASE 2: DENSE downward sweep, harvesting every step ----
        print("      sweeping through the full thread...")
        set_scroll_top(0)
        page.wait_for_timeout(pause)
        harvest()
        pos = 0
        for _ in range(4000):  # generous cap for very long threads
            st = scroller_state()
            if not st:
                break
            max_top = st["sh"] - st["ch"]
            pos = min(pos + viewport, max_top)
            set_scroll_top(pos)
            page.wait_for_timeout(pause)
            harvest()
            if pos >= max_top:
                break

    # Final harvest at the very bottom.
    scroll_container_to(1.0)
    page.wait_for_timeout(pause)
    harvest()

    # Sort into true thread order by vertical position, then drop the helper key.
    collected.sort(key=lambda m: m.get("_y", 0))
    messages = [{"role": m["role"], "text": m["text"]} for m in collected]

    # Fallback: if we somehow collected nothing, grab the main text content so
    # at least the conversation isn't lost.
    if not messages:
        try:
            body_text = page.inner_text("main")
        except Exception:
            try:
                body_text = page.inner_text("body")
            except Exception:
                body_text = ""
        if body_text.strip():
            messages = [{"role": "page_dump", "text": body_text.strip()}]

    return {
        "url": url,
        "title": title,
        "scraped_at": datetime.now().isoformat(),
        "message_count": len(messages),
        "messages": messages,
    }


# ---------------------------------------------------------------------------
# Writing output
# ---------------------------------------------------------------------------

def build_chat_html(chat):
    """Build a self-contained, styled HTML document from captured html_blocks.

    Each block's innerHTML is embedded as-is so the original formatting (bold,
    inline code, code blocks, lists, links, tables, etc.) is preserved. Basic
    CSS gives user vs. assistant messages distinct styling.
    """
    import html as _html

    title = _html.escape(chat.get("title", "Chat"))
    url = _html.escape(chat.get("url", ""))
    exported = _html.escape(chat.get("scraped_at", ""))
    blocks = chat.get("html_blocks", []) or []

    css = """
    :root { color-scheme: light dark; }
    * { box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
                   Helvetica, Arial, sans-serif;
      line-height: 1.55; margin: 0; padding: 0;
      background: #f4f5f7; color: #1a1a1a;
    }
    .wrap { max-width: 900px; margin: 0 auto; padding: 24px 16px 80px; }
    header.doc {
      position: sticky; top: 0; background: #ffffffee; backdrop-filter: blur(6px);
      padding: 16px; border-bottom: 1px solid #e2e4e8; margin-bottom: 24px;
      z-index: 5;
    }
    header.doc h1 { font-size: 1.25rem; margin: 0 0 6px; }
    header.doc .meta { font-size: .8rem; color: #666; word-break: break-all; }
    .msg { margin: 18px 0; padding: 14px 16px; border-radius: 12px;
           box-shadow: 0 1px 2px rgba(0,0,0,.06); }
    .msg .role { font-size: .72rem; font-weight: 700; text-transform: uppercase;
                 letter-spacing: .04em; margin-bottom: 8px; opacity: .7; }
    .msg.user { background: #e7f0ff; border: 1px solid #cfe0ff; }
    .msg.assistant { background: #ffffff; border: 1px solid #e6e8ec; }
    .msg pre { background: #0d1117; color: #e6edf3; padding: 12px; border-radius: 8px;
               overflow-x: auto; font-size: .85rem; }
    .msg code { background: rgba(0,0,0,.06); padding: .1em .35em; border-radius: 4px;
                font-size: .9em; }
    .msg pre code { background: transparent; padding: 0; }
    .msg img { max-width: 100%; height: auto; border-radius: 8px; }
    .msg table { border-collapse: collapse; width: 100%; margin: 8px 0; }
    .msg th, .msg td { border: 1px solid #d0d3d8; padding: 6px 10px; text-align: left; }
    .msg a { color: #1a6dff; }
    @media (prefers-color-scheme: dark) {
      body { background: #16181d; color: #e6e8ec; }
      header.doc { background: #1c1f26ee; border-bottom-color: #2a2e37; }
      header.doc .meta { color: #9aa0aa; }
      .msg.assistant { background: #1c1f26; border-color: #2a2e37; }
      .msg.user { background: #172033; border-color: #24406b; }
      .msg th, .msg td { border-color: #2a2e37; }
    }
    """

    parts = [
        "<!DOCTYPE html>",
        '<html lang="en"><head><meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        f"<title>{title}</title>",
        f"<style>{css}</style>",
        "</head><body>",
        '<header class="doc">',
        f"<h1>{title}</h1>",
        f'<div class="meta">Source: <a href="{url}">{url}</a><br>Exported: {exported} &middot; {len(blocks)} message block(s)</div>',
        "</header>",
        '<div class="wrap">',
    ]

    # Base origin for fixing up relative image/link URLs so they still work
    # when the HTML file is opened locally.
    origin = ""
    try:
        m = re.match(r"^(https?://[^/]+)", chat.get("url", ""))
        if m:
            origin = m.group(1)
    except Exception:
        origin = ""

    def fix_urls(h):
        if not origin or not h:
            return h
        # Rewrite src="/..." and href="/..." (root-relative) to absolute.
        h = re.sub(r'(\bsrc=")(/[^"]*)', r"\1" + origin + r"\2", h)
        h = re.sub(r'(\bhref=")(/[^"]*)', r"\1" + origin + r"\2", h)
        return h

    for b in blocks:
        role = b.get("role", "assistant")
        role_class = "user" if role == "user" else "assistant"
        inner = fix_urls(b.get("html", "")) or _html.escape(b.get("text", ""))
        parts.append(f'<div class="msg {role_class}">')
        parts.append(f'<div class="role">{_html.escape(role)}</div>')
        parts.append(f'<div class="content">{inner}</div>')
        parts.append("</div>")

    parts.append("</div></body></html>")
    return "\n".join(parts)


def write_outputs(chat, out_base: Path, cfg):
    org = cfg.get("folder_organization", "task")
    title_slug = slugify(chat["title"])

    if org == "date":
        date_folder = datetime.now().strftime("%Y-%m-%d")
        task_dir = unique_dir(out_base / date_folder, title_slug)
    else:  # "task" (default)
        task_dir = unique_dir(out_base, title_slug)

    task_dir.mkdir(parents=True, exist_ok=True)

    formats = cfg.get("formats", ["markdown", "json"])

    if "json" in formats:
        with open(task_dir / "chat.json", "w", encoding="utf-8") as f:
            json.dump(chat, f, ensure_ascii=False, indent=2)

    if "markdown" in formats:
        lines = [f"# {chat['title']}", ""]
        lines.append(f"- **Source:** {chat['url']}")
        lines.append(f"- **Exported:** {chat['scraped_at']}")
        lines.append(f"- **Messages:** {chat['message_count']}")
        lines.append("")
        lines.append("---")
        lines.append("")
        _use_raw = chat.get("raw_text") and len(chat["raw_text"].strip()) > 40
        if _use_raw:
            lines.append(chat["raw_text"].strip())
        for i, m in enumerate([] if _use_raw else chat["messages"], 1):
            role = m.get("role", "unknown")
            lines.append(f"## Message {i} — `{role}`")
            lines.append("")
            lines.append(m.get("text", ""))
            lines.append("")
        with open(task_dir / "chat.md", "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    # HTML export: rebuild the conversation from the captured innerHTML of each
    # message block, preserving formatting (bold, code blocks, lists, links,
    # tables, etc.) as rendered on the page.
    if "html" in formats and chat.get("html_blocks"):
        html_doc = build_chat_html(chat)
        with open(task_dir / "chat.html", "w", encoding="utf-8") as f:
            f.write(html_doc)

    # Always save the raw captured text as a safety net (complete conversation
    # exactly as selected), so nothing is lost even if message-splitting is off.
    if chat.get("raw_text"):
        with open(task_dir / "chat_full.txt", "w", encoding="utf-8") as f:
            f.write(chat["raw_text"])

    if "text" in formats:
        with open(task_dir / "chat.txt", "w", encoding="utf-8") as f:
            f.write(f"{chat['title']}\n{chat['url']}\n\n")
            for m in chat["messages"]:
                f.write(f"[{m.get('role','unknown')}]\n{m.get('text','')}\n\n")

    return task_dir


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

EXPORTER_VERSION = "v10-memory-safe-2026-07-04"


def main():
    print("=" * 70)
    print(f"  SuperNinja Exporter  {EXPORTER_VERSION}")
    print("  (If you do NOT see this banner, an OLD copy is running -")
    print("   delete the folder and unzip fresh.)")
    print("=" * 70)
    parser = argparse.ArgumentParser(description="Export SuperNinja chats to organized folders.")
    parser.add_argument("--login", action="store_true", help="Force a fresh manual login.")
    parser.add_argument("--limit", type=int, default=0, help="Only export the first N tasks (0 = all).")
    parser.add_argument("--start", type=int, default=1,
                        help="Start exporting from this task number (1-based). "
                             "E.g. --start 6 skips the first 5.")
    parser.add_argument("--end", type=int, default=0,
                        help="Stop after this task number (1-based, inclusive). 0 = go to the end.")
    args = parser.parse_args()

    cfg = load_config()
    cdp = cfg.get("connect_mode") == "cdp"
    persistent = cfg.get("use_persistent_profile", False)

    if cdp:
        # In CDP mode you log in directly in the Chrome opened by
        # 0_START_CHROME.bat, so there is no script-driven login step.
        print("Connecting to the Chrome you opened with 0_START_CHROME.bat ...")
    else:
        # Decide whether we need a script-driven manual login.
        if persistent:
            need_login = args.login or not PROFILE_DIR.exists()
        else:
            need_login = args.login or not SESSION_PATH.exists()
        if need_login:
            do_manual_login(cfg)

    out_base = HERE / cfg.get("output_dir", "SuperNinja_Export")
    out_base.mkdir(parents=True, exist_ok=True)

    manifest = []
    with sync_playwright() as p:
        browser, context = launch_browser(p, cfg, headless=cfg.get("headless_after_login", False))

        # Reuse an existing tab if one is open (CDP mode); else make a new one.
        if cdp and context.pages:
            # Prefer a tab that is already on the SuperNinja domain.
            page = None
            for pg in context.pages:
                try:
                    if "myninja.ai" in (pg.url or ""):
                        page = pg
                        break
                except Exception:
                    continue
            if page is None:
                page = context.pages[0]
        else:
            page = context.new_page()

        # Make sure we're on the app and it has actually rendered (not the
        # blank white SPA state). Reload up to a few times if the body is empty.
        try:
            if "myninja.ai" not in (page.url or ""):
                page.goto(cfg["base_url"], wait_until="domcontentloaded")
        except Exception:
            page.goto(cfg["base_url"], wait_until="domcontentloaded")

        for attempt in range(4):
            page.wait_for_timeout(2500)
            try:
                body_text = (page.inner_text("body") or "").strip()
            except Exception:
                body_text = ""
            # A rendered app has meaningful text and/or links; blank SPA does not.
            link_count = 0
            try:
                link_count = len(page.query_selector_all("a"))
            except Exception:
                pass
            if len(body_text) > 40 or link_count > 3:
                break
            print(f"  Page looks blank (attempt {attempt+1}/4) - reloading...")
            try:
                page.reload(wait_until="domcontentloaded")
            except Exception:
                page.goto(cfg["base_url"], wait_until="domcontentloaded")
        page.wait_for_timeout(cfg.get("wait_after_login_seconds", 3) * 1000)

        links = discover_task_links(page, cfg)
        if not links:
            print("\nNo task links were found. This usually means either:")
            print("  - The session expired (run:  python export_chats.py --login), or")
            print("  - The sidebar selectors need adjusting in config.json.")
            if not cdp:
                (browser or context).close()
            return

        total_found = len(links)
        print(f"Discovered {total_found} task(s) total.")

        # Apply --start / --end / --limit windowing (all 1-based, inclusive).
        start_i = max(1, args.start)
        if args.end and args.end > 0:
            end_i = min(args.end, total_found)
        elif args.limit and args.limit > 0:
            end_i = min(start_i + args.limit - 1, total_found)
        else:
            end_i = total_found

        if start_i > total_found:
            print(f"Start index {start_i} is beyond the {total_found} tasks found. Nothing to do.")
            if not cdp:
                (browser or context).close()
            return

        # Slice while remembering each task's ORIGINAL 1-based number.
        windowed = [(n, links[n - 1]) for n in range(start_i, end_i + 1)]
        print(f"Exporting tasks {start_i} through {end_i} "
              f"({len(windowed)} of {total_found}).")

        for idx, link in windowed:
            print(f"[{idx}/{len(links)}] Exporting: {link['label'] or link['url']}")
            chat = None
            # Try up to 3 times. Recovers from: (a) the harmless Playwright
            # frame-detach glitch, and (b) a Chrome "Aw, Snap" crash on a very
            # large thread (out of memory) - in which case we reload the page
            # (or open a fresh tab) and retry instead of silently skipping.
            max_attempts = cfg.get("task_retries", 3)
            for attempt in range(max_attempts):
                try:
                    chat = extract_chat(page, cfg, link["url"], fallback_title=link.get("label"))
                    break
                except PWTimeout:
                    print(f"      !! Timed out on {link['url']} — skipping.")
                    chat = None
                    break
                except Exception as e:
                    msg = str(e)
                    last = attempt >= max_attempts - 1
                    crashy = any(s in msg.lower() for s in (
                        "list.remove", "crash", "target closed", "page closed",
                        "context or browser has been closed", "detached",
                        "navigation", "connection closed",
                    ))
                    if crashy and not last:
                        print(f"      .. page glitch/crash ({msg[:60]}...); "
                              f"recovering and retrying task {idx} "
                              f"(attempt {attempt+2}/{max_attempts})...")
                        # Try to bring the page back to life. If the tab crashed,
                        # reload it; if the tab is gone, open a fresh one.
                        try:
                            page.wait_for_timeout(2000)
                            page.reload(wait_until="domcontentloaded")
                            page.wait_for_timeout(2500)
                        except Exception:
                            try:
                                page = context.new_page()
                                page.goto(cfg["base_url"], wait_until="domcontentloaded")
                                page.wait_for_timeout(2500)
                            except Exception:
                                pass
                        continue
                    print(f"      !! Error on {link['url']}: {msg}")
                    chat = None
                    break

            if chat is None:
                continue

            try:
                folder = write_outputs(chat, out_base, cfg)
                manifest.append({
                    "index": idx,
                    "title": chat["title"],
                    "url": chat["url"],
                    "messages": chat["message_count"],
                    "folder": str(folder.relative_to(HERE)),
                })
                print(f"      -> saved {chat['message_count']} message(s) to {folder.name}/")
            except Exception as e:
                print(f"      !! Error saving {link['url']}: {e}")

        # In CDP mode, leave your real Chrome open (just disconnect).
        if not cdp:
            (browser or context).close()

    with open(out_base / "manifest.json", "w", encoding="utf-8") as f:
        json.dump({"exported_at": datetime.now().isoformat(), "tasks": manifest}, f,
                  ensure_ascii=False, indent=2)

    print("\n" + "=" * 70)
    print(f"DONE. Exported {len(manifest)} task(s).")
    print(f"Output folder: {out_base}")
    print(f"Index/manifest: {out_base / 'manifest.json'}")
    print("=" * 70)


if __name__ == "__main__":
    main()
