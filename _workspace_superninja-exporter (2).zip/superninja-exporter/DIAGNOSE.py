#!/usr/bin/env python3
"""
Diagnostic tool for the SuperNinja Exporter.

Attaches to the Chrome you opened with 0_START_CHROME.bat and dumps information
about the CURRENT page. Run it TWICE for best results:
  A) While looking at your DASHBOARD (task list)  -> helps with task discovery
  B) While a CHAT / task thread is OPEN            -> helps with message capture

It writes diagnostics.txt and page_dump.html. Send me diagnostics.txt.
"""

import json
from pathlib import Path
from collections import Counter

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("Playwright not installed. Run 1_SETUP.bat first.")
    raise SystemExit(1)

HERE = Path(__file__).resolve().parent
CFG = json.load(open(HERE / "config.json", encoding="utf-8"))
PORT = CFG.get("cdp_port", 9222)
OUT = HERE / "diagnostics.txt"


def main():
    lines = []

    def log(s=""):
        print(s)
        lines.append(str(s))

    with sync_playwright() as p:
        try:
            browser = p.chromium.connect_over_cdp(f"http://localhost:{PORT}")
        except Exception as e:
            log(f"ERROR: could not connect to Chrome on port {PORT}: {e}")
            OUT.write_text("\n".join(lines), encoding="utf-8")
            return

        ctx = browser.contexts[0] if browser.contexts else browser.new_context()

        page = None
        log("Open tabs:")
        for pg in ctx.pages:
            log(f"  - {pg.url}")
            if "myninja.ai" in (pg.url or "") and page is None:
                page = pg
        if page is None and ctx.pages:
            page = ctx.pages[0]
        if page is None:
            log("No pages open.")
            OUT.write_text("\n".join(lines), encoding="utf-8")
            return

        log("")
        log("=" * 60)
        log(f"ACTIVE PAGE URL : {page.url}")
        log(f"ACTIVE PAGE TITLE: {page.title()}")
        log("=" * 60)

        is_chat = "/agents/" in (page.url or "")
        log(f"This looks like a {'CHAT/TASK page' if is_chat else 'dashboard/list page'}.")

        # ---- TASK DISCOVERY INFO (href prefixes) ----
        hrefs = page.eval_on_selector_all("a", "els => els.map(e => e.getAttribute('href'))")
        hrefs = [h for h in hrefs if h]
        prefixes = Counter()
        for h in hrefs:
            seg = h.split("?")[0].strip("/").split("/")
            if seg and seg[0]:
                prefixes["/" + seg[0]] += 1
        log("\n--- HREF PATH-PREFIX FREQUENCY ---")
        for pref, cnt in prefixes.most_common(15):
            log(f"  {cnt:4d}  {pref}/...")

        # ---- CHAT MESSAGE STRUCTURE ANALYSIS ----
        log("\n--- CANDIDATE MESSAGE CONTAINERS ---")
        # For a range of selectors, report how many match and a text sample.
        candidates = [
            "[data-testid*='message']",
            "[data-message-author-role]",
            "[class*='message']",
            "[class*='Message']",
            "[class*='chat']",
            "[class*='Chat']",
            "[class*='bubble']",
            "[class*='Bubble']",
            "[class*='turn']",
            "[class*='Turn']",
            "[class*='markdown']",
            "[class*='Markdown']",
            ".prose",
            "article",
            "[role='listitem']",
            "main div",
        ]
        for sel in candidates:
            try:
                n = len(page.query_selector_all(sel))
            except Exception:
                n = -1
            log(f"  {n:5d}  matches  ->  {sel}")

        # Report class names of likely message elements (sampled)
        log("\n--- SAMPLE class attributes seen inside <main> (first 50 unique) ---")
        try:
            classes = page.eval_on_selector_all(
                "main *",
                "els => els.map(e => e.className).filter(c => typeof c === 'string' && c.length)"
            )
        except Exception:
            classes = []
        seen = []
        for c in classes:
            c = str(c)
            # keep classes that look message/chat/turn/markdown related, plus a few others
            if c not in seen:
                seen.append(c)
        # Prioritize ones that hint at messages
        hints = [c for c in seen if any(k in c.lower() for k in
                 ("message", "chat", "turn", "bubble", "markdown", "prose", "content", "answer", "response", "user", "assistant"))]
        others = [c for c in seen if c not in hints]
        for c in (hints + others)[:50]:
            log(f"  class=\"{c[:140]}\"")

        # Identify the largest scrollable container (the message scroll area)
        log("\n--- SCROLLABLE CONTAINERS (scrollHeight > clientHeight) ---")
        try:
            scrollers = page.evaluate(
                """() => {
                    const out = [];
                    document.querySelectorAll('*').forEach(e => {
                        if (e.scrollHeight > e.clientHeight + 50 && e.clientHeight > 200) {
                            out.push({
                                tag: e.tagName.toLowerCase(),
                                cls: (typeof e.className === 'string' ? e.className : ''),
                                sh: e.scrollHeight, ch: e.clientHeight
                            });
                        }
                    });
                    return out.slice(0, 15);
                }"""
            )
            for s in scrollers:
                log(f"  <{s['tag']}> sh={s['sh']} ch={s['ch']} class=\"{str(s['cls'])[:100]}\"")
        except Exception as e:
            log(f"  (could not analyze scrollers: {e})")

        # Save full HTML
        try:
            html = page.content()
            name = "page_dump_chat.html" if is_chat else "page_dump_dashboard.html"
            (HERE / name).write_text(html, encoding="utf-8")
            log(f"\nSaved full page HTML to {name}")
        except Exception as e:
            log(f"\nCould not save HTML: {e}")

    OUT.write_text("\n".join(lines), encoding="utf-8")
    print("\n" + "=" * 60)
    print(f"Diagnostics written to: {OUT.name}")
    print("If you ran this on a CHAT page, also send the page_dump_chat.html file.")
    print("=" * 60)


if __name__ == "__main__":
    main()
