@echo off
REM ============================================================
REM  SuperNinja Exporter - FIND THE "JUMP TO TOP" BUTTON
REM  Run this WITH Chrome open (0_START_CHROME.bat), with a CHAT
REM  OPEN and scrolled down a bit so the floating up-arrow button
REM  is visible. It dumps info about that button to top_button.txt.
REM ============================================================
echo.
echo === Find the "Jump to Top" button ===
echo.
echo Make sure:
echo   1. You ran 0_START_CHROME.bat and are LOGGED IN.
echo   2. A CHAT (e.g. "Single Mic Unit Setup") is OPEN.
echo   3. You have SCROLLED DOWN a little so the round up-arrow
echo      button is VISIBLE on screen.
echo   4. That Chrome window is still OPEN.
echo.
pause

if not exist venv\Scripts\activate.bat (
    echo ERROR: Run 1_SETUP.bat first.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
python FIND_TOP_BUTTON.py

echo.
echo Done. A file named  top_button.txt  was created in this folder.
echo Please send  top_button.txt  back so I can target the button exactly.
echo.
pause
