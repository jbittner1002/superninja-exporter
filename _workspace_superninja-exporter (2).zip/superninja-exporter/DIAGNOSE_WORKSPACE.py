#!/usr/bin/env python3
"""
Workspace DOM diagnostic
------------------------
Opens the FIRST task, tries to click the workspace/folder button, then dumps
information about the buttons and file-tree rows it finds into
'workspace_dom.txt'. Use this if download_workspace.py doesn't find the
workspace button or files, so we can tune the selectors.

Run after 0_START_CHROME.bat (Chrome open + logged in).
"""
import json
from pathlib import Path

from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
CONFIG_PATH = HERE / "config.json"


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    cfg = load_config()
    port = cfg.get("cdp_port", 9222)
    out_lines = []

    def log(s=""):
        print(s)
        out_lines.append(str(s))

    with sync_playwright() as p:
        browser = p.chromium.connect_over_cdp(f"http://localhost:{port}")
        context = browser.contexts[0] if browser.contexts else browser.new_context()
        page = None
        for pg in context.pages:
            if "myninja.ai" in (pg.url or ""):
                page = pg
                break
        if page is None:
            page = context.pages[0] if context.pages else context.new_page()

        if "myninja.ai" not in (page.url or ""):
            page.goto(cfg["base_url"], wait_until="domcontentloaded")
            page.wait_for_timeout(3000)

        # Find first task link and open it.
        links = []
        for sel in cfg["selectors"]["task_list_links"]:
            for h in page.query_selector_all(sel):
                href = h.get_attribute("href")
                if href and "/agents/" in href:
                    if href.startswith("/"):
                        href = cfg["base_url"].rstrip("/") + href
                    links.append(href)
            if links:
                break
        if links:
            log(f"Opening first task: {links[0]}")
            page.goto(links[0], wait_until="domcontentloaded")
            page.wait_for_timeout(3000)
        else:
            log("No task links found; diagnosing on the current page.")

        # 1) Dump all buttons with an icon or a numeric badge (candidates for
        #    the workspace/folder button).
        log("\n=== BUTTONS WITH ICONS / BADGES ===")
        btns = page.evaluate(
            r"""() => {
                const out = [];
                const els = Array.from(document.querySelectorAll('button, [role="button"], a'));
                for (const b of els) {
                    const rect = b.getBoundingClientRect();
                    if (rect.width === 0 || rect.height === 0) continue;
                    const svgPath = b.querySelector('svg path');
                    const d = svgPath ? (svgPath.getAttribute('d') || '').slice(0, 40) : '';
                    const txt = (b.textContent || '').trim().slice(0, 30);
                    const aria = b.getAttribute('aria-label') || '';
                    const title = b.getAttribute('title') || '';
                    // Only keep ones that look interesting.
                    if (d || /\d/.test(txt) || /work|file|folder/i.test(aria + ' ' + title + ' ' + txt)) {
                        out.push({
                            x: Math.round(rect.x), y: Math.round(rect.y),
                            w: Math.round(rect.width), h: Math.round(rect.height),
                            text: txt, aria, title, pathStart: d,
                        });
                    }
                }
                return out;
            }"""
        )
        for b in btns:
            log(json.dumps(b, ensure_ascii=False))

        # 2) Open the workspace panel via the folder icon, then dump the header
        #    buttons (so we can identify the "..." 3-dots button) and the menu.
        log("\n=== ATTEMPT TO OPEN WORKSPACE PANEL ===")
        try:
            from download_workspace import (OPEN_WORKSPACE_PANEL_JS,
                                            OPEN_HEADER_MENU_JS,
                                            CLICK_DOWNLOAD_ALL_JS,
                                            HEADER_ROW_BOX_JS,
                                            CLICK_DOTS_BY_INDEX_JS,
                                            HAS_DOWNLOAD_ALL_JS)
        except Exception as e:
            log(f"(could not import downloader JS: {e})")
            OPEN_WORKSPACE_PANEL_JS = OPEN_HEADER_MENU_JS = "() => ''"
            CLICK_DOWNLOAD_ALL_JS = "() => false"
            HEADER_ROW_BOX_JS = "() => null"
            CLICK_DOTS_BY_INDEX_JS = "(i) => ({count:0,clicked:false})"
            HAS_DOWNLOAD_ALL_JS = "() => false"
            GLOBAL_ACTIONS_BOX_JS = "() => null"
        try:
            from download_workspace import GLOBAL_ACTIONS_BOX_JS
        except Exception:
            GLOBAL_ACTIONS_BOX_JS = "() => null"

        def panel_open():
            try:
                return bool(page.evaluate(
                    "() => Array.from(document.querySelectorAll('*'))"
                    ".some(el => (el.textContent||'').trim().startsWith('Workspace Files'))"))
            except Exception:
                return False

        how = ""
        for _t in range(6):
            if panel_open():
                how = how or "already-open"
                break
            how = page.evaluate(OPEN_WORKSPACE_PANEL_JS)
            log(f"open-panel attempt {_t+1}: {how!r}")
            page.wait_for_timeout(1500)
            if panel_open():
                break
        log(f"open-panel result: {how!r}  panel_open={panel_open()}")
        page.wait_for_timeout(1500)

        # Dump top-toolbar buttons (y<120) so we can see the folder icon sig.
        log("\n=== TOP TOOLBAR BUTTONS (y<120) ===")
        top_btns = page.evaluate(
            r"""() => {
                const out = [];
                for (const b of document.querySelectorAll('button, [role="button"]')) {
                    const r = b.getBoundingClientRect();
                    if (r.width===0 || r.height===0 || r.y>=120) continue;
                    const d = (b.querySelector('svg path')?.getAttribute('d')||'').slice(0,24);
                    out.push({x:Math.round(r.x), y:Math.round(r.y), w:Math.round(r.width),
                              aria:b.getAttribute('aria-label')||'', pathStart:d});
                }
                out.sort((a,b)=>a.x-b.x);
                return out;
            }"""
        )
        for b in top_btns:
            log(json.dumps(b, ensure_ascii=False))

        # Dump every small icon button near the top of the panel (candidates for
        # the "..." menu), with SVG path signatures.
        log("\n=== PANEL HEADER BUTTONS (small icon buttons) ===")
        hdr_btns = page.evaluate(
            r"""() => {
                const out = [];
                const btns = Array.from(document.querySelectorAll('button, [role="button"]'));
                for (const b of btns) {
                    const r = b.getBoundingClientRect();
                    if (r.width === 0 || r.height === 0) continue;
                    const svg = b.querySelector('svg');
                    if (!svg) continue;
                    const d = (svg.querySelector('path')?.getAttribute('d') || '').slice(0, 30);
                    const circles = b.querySelectorAll('svg circle').length;
                    out.push({
                        x: Math.round(r.x), y: Math.round(r.y),
                        w: Math.round(r.width), h: Math.round(r.height),
                        aria: b.getAttribute('aria-label') || '',
                        title: b.getAttribute('title') || '',
                        circles, pathStart: d,
                    });
                }
                // Sort top-to-bottom, left-to-right.
                out.sort((a,b) => (a.y-b.y) || (a.x-b.x));
                return out;
            }"""
        )
        for b in hdr_btns:
            log(json.dumps(b, ensure_ascii=False))

        # 2b) Physically hover the header row (Name/Modified/Size) so the
        #     hover-only "..." control appears, then dump what shows up.
        log("\n=== HEADER ROW BOX + REAL-MOUSE HOVER ===")
        box = None
        try:
            box = page.evaluate(HEADER_ROW_BOX_JS)
        except Exception as e:
            log(f"(header-row-box error: {e})")
        log(f"header-row box: {box!r}")
        if box and box.get("w", 0) > 0:
            try:
                cx = box["x"] + box["w"] / 2
                cy = box["y"] + box["h"] / 2
                page.mouse.move(cx, cy)
                page.wait_for_timeout(150)
                page.mouse.move(box["x"] + box["w"] - 12, cy)
                page.wait_for_timeout(300)
                log("(moved real mouse across header row)")
            except Exception as e:
                log(f"(mouse move error: {e})")

        # After hovering, dump any small icon buttons that appeared in the
        # panel header band (right side), so we can see the "..." if present.
        log("\n=== SMALL ICON BUTTONS AFTER HOVER (panel region, x>700) ===")
        hover_btns = page.evaluate(
            r"""() => {
                const out = [];
                const btns = Array.from(document.querySelectorAll('button, [role="button"]'));
                for (const b of btns) {
                    const r = b.getBoundingClientRect();
                    if (r.width === 0 || r.height === 0 || r.width >= 60) continue;
                    if (r.x < 600) continue;  // skip left sidebar
                    const svg = b.querySelector('svg');
                    const d = svg ? (svg.querySelector('path')?.getAttribute('d') || '').slice(0,24) : '';
                    const circles = b.querySelectorAll('svg circle').length;
                    out.push({ x: Math.round(r.x), y: Math.round(r.y),
                               w: Math.round(r.width), circles, pathStart: d });
                }
                out.sort((a,b)=>(a.y-b.y)||(a.x-b.x));
                return out.slice(0, 40);
            }"""
        )
        for b in hover_btns:
            log(json.dumps(b, ensure_ascii=False))

        # 2b-real) REAL-CLICK the "Global actions" header kebab and dump the
        #          menu that appears (Radix menus need a real pointer event).
        log("\n=== REAL-CLICK 'Global actions' KEBAB + DUMP MENU ===")
        try:
            gbox = page.evaluate(GLOBAL_ACTIONS_BOX_JS)
        except Exception as e:
            gbox = None
            log(f"(global-actions box error: {e})")
        log(f"global-actions box: {gbox!r}")
        if gbox and gbox.get("w", 0) > 0:
            try:
                gx = gbox["x"] + gbox["w"] / 2
                gy = gbox["y"] + gbox["h"] / 2
                page.mouse.move(gx, gy)
                page.wait_for_timeout(150)
                page.mouse.click(gx, gy)
                page.wait_for_timeout(600)
                log(f"(real-clicked global-actions at {int(gx)},{int(gy)})")
                # Dump EVERYTHING that looks like a menu/popover item now.
                menu = page.evaluate(
                    r"""() => {
                        const norm = s => (s||'').replace(/\s+/g,' ').trim();
                        const out = []; const seen = new Set();
                        // Radix portals: role=menu / menuitem / data-radix, plus
                        // any fixed/absolute popover near the click.
                        const sels = ['[role="menu"] *','[role="menuitem"]',
                            '[data-radix-collection-item]','[data-radix-popper-content-wrapper] *',
                            '[class*="popover"] *','[class*="Popover"] *',
                            '[class*="dropdown"] *','[class*="Dropdown"] *'];
                        for (const sel of sels) {
                            for (const e of document.querySelectorAll(sel)) {
                                const t = norm(e.textContent);
                                if (!t || t.length > 40 || seen.has(e.tagName+'|'+t)) continue;
                                seen.add(e.tagName+'|'+t);
                                out.push({tag:e.tagName, role:e.getAttribute('role')||'', text:t});
                            }
                        }
                        return out.slice(0, 40);
                    }"""
                )
                for m in menu:
                    log(json.dumps(m, ensure_ascii=False))
                log(f"HAS_DOWNLOAD_ALL after real click: {bool(page.evaluate(HAS_DOWNLOAD_ALL_JS))}")
                try:
                    page.keyboard.press("Escape")
                except Exception:
                    pass
            except Exception as e:
                log(f"(real-click error: {e})")

        # 2c) Count the kebab "..." menus, then click each of the first few and
        #     report which one exposes a "Download all" item.
        log("\n=== KEBAB '...' MENUS: PROBE FOR 'Download all' ===")
        try:
            page.evaluate(OPEN_HEADER_MENU_JS)  # re-hover to reveal kebabs
        except Exception as e:
            log(f"(hover error: {e})")
        page.wait_for_timeout(400)
        try:
            info = page.evaluate(CLICK_DOTS_BY_INDEX_JS, -1)
            n_dots = int(info.get("count", 0)) if isinstance(info, dict) else 0
        except Exception as e:
            n_dots = 0
            log(f"(count error: {e})")
        log(f"kebab count: {n_dots}")
        for i in range(min(n_dots, 6)):
            try:
                page.evaluate(OPEN_HEADER_MENU_JS)
                page.wait_for_timeout(150)
                res = page.evaluate(CLICK_DOTS_BY_INDEX_JS, i)
                page.wait_for_timeout(450)
                has_da = bool(page.evaluate(HAS_DOWNLOAD_ALL_JS))
                log(f"  kebab #{i}: clicked={res} has_download_all={has_da}")
                if has_da:
                    # dump the menu items for this kebab
                    items = page.evaluate(
                        r"""() => {
                            const norm = s => (s||'').replace(/\s+/g,' ').trim();
                            const out = []; const seen = new Set();
                            for (const e of document.querySelectorAll(
                                '[role="menuitem"], [data-radix-collection-item], [role="menu"] *')) {
                                const t = norm(e.textContent);
                                if (!t || t.length > 40 || seen.has(t)) continue;
                                seen.add(t); out.push(t);
                            }
                            return out.slice(0, 25);
                        }"""
                    )
                    log(f"    menu items: {items}")
                page.keyboard.press("Escape")
                page.wait_for_timeout(150)
            except Exception as e:
                log(f"  kebab #{i}: error {e}")

        # 3) Try to open the "..." header menu and dump the menu items.
        log("\n=== OPEN '...' HEADER MENU ===")
        opened = page.evaluate(OPEN_HEADER_MENU_JS)
        log(f"open-menu result: {opened!r}")
        page.wait_for_timeout(800)

        log("\n=== ALL SHORT MENU/POPOVER ITEMS AFTER '...' CLICK ===")
        # Dump role=menuitem items and any short leaf text that looks like a
        # menu option, so we can see EXACTLY what the header menu contains.
        menu_items = page.evaluate(
            r"""() => {
                const out = [];
                const seen = new Set();
                // Radix/menus usually use role=menuitem or data-radix items.
                const els = Array.from(document.querySelectorAll(
                    '[role="menuitem"], [role="menu"] *, [data-radix-collection-item], [class*="menu"] *, [class*="Menu"] *'));
                for (const e of els) {
                    const t = (e.textContent || '').replace(/\s+/g,' ').trim();
                    if (!t || t.length > 40) continue;
                    const key = e.tagName + '|' + t;
                    if (seen.has(key)) continue;
                    seen.add(key);
                    out.push({ tag: e.tagName, role: e.getAttribute('role')||'', text: t });
                }
                return out.slice(0, 40);
            }"""
        )
        for m in menu_items:
            log(json.dumps(m, ensure_ascii=False))
        log(f"\n'Download all' clickable found: "
            f"{bool([m for m in menu_items if m['text'].lower().startswith('download all')])}")

        # Also: try clicking Download all with the downloader's own JS and report.
        try:
            clicked_dl = page.evaluate(CLICK_DOWNLOAD_ALL_JS)
        except Exception as e:
            clicked_dl = f"error: {e}"
        log(f"CLICK_DOWNLOAD_ALL_JS result: {clicked_dl!r}")

    (HERE / "workspace_dom.txt").write_text("\n".join(out_lines), encoding="utf-8")
    print("\nWrote workspace_dom.txt - send that file back so selectors can be tuned.")


if __name__ == "__main__":
    main()
