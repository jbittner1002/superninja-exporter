@echo off
REM ============================================================
REM  SuperNinja Chat Exporter - START CHROME (Windows)
REM  Double-click this FIRST, before running the export.
REM
REM  Opens your NORMAL Chrome (no automation flags) with a remote
REM  debugging port so the exporter can attach to it. Google
REM  sign-in works in this window.
REM ============================================================
echo.
echo === Starting Chrome for SuperNinja Exporter ===
echo.

set "PROFILE_DIR=%~dp0chrome_profile"

set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"

if "%CHROME%"=="" (
    echo ERROR: Could not find Google Chrome in the usual locations.
    echo Please install Chrome from https://www.google.com/chrome/
    echo.
    pause
    exit /b 1
)

echo Found Chrome at:
echo   %CHROME%
echo.
echo IMPORTANT: If any other Chrome windows are open, CLOSE THEM FIRST,
echo then run this again. Otherwise the debug port won't attach.
echo.

REM Notes on flags:
REM   --remote-debugging-port : lets the exporter attach
REM   --user-data-dir         : dedicated profile so your login is saved
REM   --no-first-run etc.     : skip setup prompts
REM We deliberately open the SIGN-IN URL. If the app shows a blank white
REM page, just press Ctrl+R (refresh) in Chrome - a fresh profile sometimes
REM needs one reload before the app renders.

REM   --js-flags=--expose-gc      : lets the exporter ask Chrome to free memory
REM                                 between steps on very long chats (avoids the
REM                                 "Aw, Snap / out of memory" crash).
REM   --enable-precise-memory-info: accurate heap size reporting for the log.
start "" "%CHROME%" ^
 --remote-debugging-port=9222 ^
 --user-data-dir="%PROFILE_DIR%" ^
 --no-first-run ^
 --no-default-browser-check ^
 --js-flags=--expose-gc ^
 --enable-precise-memory-info ^
 --new-window ^
 "https://super.myninja.ai/"

echo Chrome is opening at https://super.myninja.ai/
echo.
echo ---------------------------------------------------------------
echo IF THE PAGE IS BLANK / ALL WHITE:
echo   The SuperNinja app just needs a reload on a fresh profile.
echo   Do ONE of these in the Chrome window:
echo     1. Press  Ctrl + Shift + R   (hard refresh), or
echo     2. Press  Ctrl + R           (normal refresh), or
echo     3. Click the address bar and press Enter to reload.
echo   Wait a few seconds - the login screen should appear.
echo   (Do NOT type /login - this app signs in from the main URL.)
echo   If still blank after 2 reloads, wait 15s and refresh once more.
echo ---------------------------------------------------------------
echo.
echo After you are logged in and can SEE YOUR TASKS, leave Chrome open
echo and run  3_TEST_FIRST_5.bat  (or 2_RUN.bat).
echo.
echo You can close THIS black window now.
echo.
pause
