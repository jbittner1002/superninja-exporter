@echo off
REM ============================================================
REM  SuperNinja Chat Exporter - ONE-TIME SETUP (Windows)
REM  Double-click this file the FIRST time only.
REM ============================================================
echo.
echo === SuperNinja Exporter: Setup ===
echo.

REM Check Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python was not found on your PATH.
    echo Please install Python 3.11 or 3.12 from https://www.python.org/downloads/
    echo During install, TICK the box "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

echo Detected Python version:
python --version
echo.

REM Remove any half-built environment from a previous failed attempt
if exist venv (
    echo Removing previous virtual environment from earlier attempt...
    rmdir /s /q venv
)

echo Creating a local Python virtual environment...
python -m venv venv
if errorlevel 1 (
    echo ERROR: Could not create virtual environment.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat

echo Upgrading pip / wheel / setuptools...
python -m pip install --upgrade pip setuptools wheel

echo.
echo -------------------------------------------------------------------
echo STEP 1 of 3: Installing greenlet from a PREBUILT wheel (no compiling)
echo -------------------------------------------------------------------
REM This is the critical fix. We install a modern greenlet that has a
REM prebuilt wheel for your Python version, BEFORE Playwright, and force
REM pip to refuse any source build with --only-binary=:all:.
pip install --only-binary=:all: "greenlet>=3.1.1"
if errorlevel 1 (
    echo.
    echo ===============================================================
    echo Could not fetch a prebuilt greenlet wheel for your Python.
    echo This happens on brand-new / unsupported Python versions.
    echo FIX: Install Python 3.12 from https://www.python.org/downloads/
    echo      then delete the 'venv' folder and run 1_SETUP.bat again.
    echo ===============================================================
    echo.
    pause
    exit /b 1
)

echo.
echo -------------------------------------------------------------------
echo STEP 2 of 3: Installing Playwright
echo -------------------------------------------------------------------
REM greenlet is already satisfied, so Playwright will not try to build it.
pip install --prefer-binary "playwright>=1.49.0"
if errorlevel 1 (
    echo ERROR: Playwright install failed. See messages above.
    pause
    exit /b 1
)

echo.
echo -------------------------------------------------------------------
echo STEP 3 of 3: Downloading the Chromium browser for Playwright
echo -------------------------------------------------------------------
python -m playwright install chromium
if errorlevel 1 (
    echo ERROR: Playwright browser download failed.
    pause
    exit /b 1
)

echo.
echo Verifying installation...
python -c "import playwright, greenlet; print('Playwright + greenlet OK -> greenlet', greenlet.__version__)"
if errorlevel 1 (
    echo ERROR: Verification failed.
    pause
    exit /b 1
)

echo.
echo === Setup complete! ===
echo You can now double-click  3_TEST_FIRST_5.bat  to test,
echo then  2_RUN.bat  for a full export.
echo.
pause
