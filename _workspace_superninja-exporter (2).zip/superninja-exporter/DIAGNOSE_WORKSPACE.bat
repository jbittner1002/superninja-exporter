@echo off
REM ============================================================
REM  Workspace DOM diagnostic
REM  Opens the FIRST task, tries to open the workspace panel,
REM  and dumps the DOM to workspace_dom.txt so the file-tree
REM  selectors can be tuned if downloads don't work.
REM ============================================================
echo.
echo === Workspace DOM Diagnostic ===
echo.
echo BEFORE running this:
echo   1. Double-click  0_START_CHROME.bat  and log into SuperNinja.
echo   2. Leave that Chrome window OPEN, then continue here.
echo.
pause

if not exist venv\Scripts\activate.bat (
    echo ERROR: Setup has not been run yet. Run  1_SETUP.bat  first.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
python DIAGNOSE_WORKSPACE.py

echo.
echo Done. Please send back the file  workspace_dom.txt
echo.
pause
