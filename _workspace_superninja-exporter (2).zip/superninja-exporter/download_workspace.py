#!/usr/bin/env python3
"""
SuperNinja Workspace Downloader
-------------------------------
A SEPARATE companion to export_chats.py.

For each task, this script:
  1. Opens the task (navigates to its /agents/ URL).
  2. Clicks the "workspace" / folder button (the folder icon with the file-count
     badge, e.g. "100+") to open the workspace file panel.
  3. Walks the whole workspace tree - expanding every folder / subdirectory.
  4. Downloads EVERY file (including files nested in subdirectories) into that
     task's folder inside SuperNinja_Export, preserving the subdirectory
     structure under a "workspace/" subfolder.

It reuses the SAME connection (CDP attach to your logged-in Chrome), the SAME
config.json, and the SAME task discovery + folder-naming as export_chats.py,
so the downloaded files land next to the chat exports for each task.

Usage (mirrors export_chats.py):
    python download_workspace.py                 # all tasks
    python download_workspace.py --limit 5       # first 5 tasks (test)
    python download_workspace.py --start 6       # start at task 6
    python download_workspace.py --start 6 --end 20
    python download_workspace.py --login         # force fresh manual login

Run it AFTER 0_START_CHROME.bat (Chrome open + logged in), just like the
chat exporter. Use TEST_DOWNLOAD_FIRST_5.bat to test and RUN_DOWNLOAD_ALL.bat
for the full run.
"""

import argparse
import json
import re
import sys
import time
from datetime import datetime
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
except ImportError:
    print("ERROR: Playwright is not installed.")
    print("Run:  pip install -r requirements.txt")
    print("Then: python -m playwright install chromium")
    sys.exit(1)


HERE = Path(__file__).resolve().parent
CONFIG_PATH = HERE / "config.json"
SESSION_PATH = HERE / "session_state.json"
PROFILE_DIR = HERE / "chrome_profile"

DOWNLOADER_VERSION = "wsdl-v10-longwait-bigdl-2026-07-05"


# ---------------------------------------------------------------------------
# Silence the harmless Playwright frame-detach noise (same patch as the
# chat exporter). SuperNinja swaps out iframes as it re-renders, which makes
# Playwright's internal listener occasionally raise a cosmetic ValueError.
# ---------------------------------------------------------------------------
def _patch_playwright_frame_detach_noise():
    try:
        from playwright._impl import _page as _pw_page
        _orig = _pw_page.Page._on_frame_detached

        def _safe(self, frame):
            try:
                _orig(self, frame)
            except Exception:
                pass

        _pw_page.Page._on_frame_detached = _safe
    except Exception:
        pass


_patch_playwright_frame_detach_noise()


# ---------------------------------------------------------------------------
# Config / browser connection  (identical approach to export_chats.py)
# ---------------------------------------------------------------------------
def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def connect_over_cdp(p, cfg):
    port = cfg.get("cdp_port", 9222)
    endpoint = f"http://localhost:{port}"
    try:
        browser = p.chromium.connect_over_cdp(endpoint)
    except Exception as e:
        print("\n" + "=" * 70)
        print("COULD NOT CONNECT TO CHROME")
        print("=" * 70)
        print(f"Tried to attach to Chrome at {endpoint} but failed.")
        print("Make sure you FIRST double-clicked  0_START_CHROME.bat  and that")
        print("the Chrome window it opened is still OPEN and logged in.")
        print(f"(Underlying error: {e})")
        print("=" * 70 + "\n")
        raise
    context = browser.contexts[0] if browser.contexts else browser.new_context()
    return browser, context


def launch_browser(p, cfg, headless):
    if cfg.get("connect_mode") == "cdp":
        return connect_over_cdp(p, cfg)
    channel = cfg.get("browser_channel")
    launch_kwargs = {"headless": headless}
    if channel:
        launch_kwargs["channel"] = channel
    if cfg.get("use_persistent_profile", False):
        PROFILE_DIR.mkdir(parents=True, exist_ok=True)
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(PROFILE_DIR), headless=headless,
            channel=channel if channel else None,
        )
        return None, context
    browser = p.chromium.launch(**launch_kwargs)
    if SESSION_PATH.exists():
        context = browser.new_context(storage_state=str(SESSION_PATH))
    else:
        context = browser.new_context()
    return browser, context


# ---------------------------------------------------------------------------
# Naming helpers (same as export_chats.py so folders line up)
# ---------------------------------------------------------------------------
def slugify(text, max_len=80):
    if not text:
        text = "untitled"
    text = text.strip()
    text = re.sub(r'[\\/:*?"<>|]', "", text)
    text = re.sub(r"\s+", "_", text)
    text = re.sub(r"[^A-Za-z0-9._\-]", "", text)
    text = text.strip("._-")
    if not text:
        text = "untitled"
    return text[:max_len]


def safe_rel_path(path_str):
    """Sanitize a workspace-relative path into a safe path under our folder.

    Keeps directory separators (so subdirectories are preserved) but sanitizes
    each segment and strips any leading slashes / drive letters / '..'.
    """
    if not path_str:
        return "unnamed_file"
    path_str = path_str.replace("\\", "/").strip()
    # Drop a leading /workspace or / so it becomes relative.
    path_str = re.sub(r"^/?workspace/?", "", path_str, flags=re.IGNORECASE)
    path_str = path_str.lstrip("/")
    parts = []
    for seg in path_str.split("/"):
        seg = seg.strip()
        if seg in ("", ".", ".."):
            continue
        seg = re.sub(r'[\\/:*?"<>|]', "_", seg)
        parts.append(seg)
    if not parts:
        return "unnamed_file"
    return "/".join(parts)


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------
def do_manual_login(cfg):
    print("\n" + "=" * 70)
    print("MANUAL LOGIN")
    print("=" * 70)
    print("A Chrome window will open. Log into SuperNinja, make sure you can")
    print("see your tasks, then return here and press ENTER.")
    print("=" * 70 + "\n")
    with sync_playwright() as p:
        browser, context = launch_browser(p, cfg, headless=False)
        page = context.new_page()
        page.goto(cfg["base_url"], wait_until="domcontentloaded")
        input(">>> After logging in, press ENTER here... ")
        try:
            context.storage_state(path=str(SESSION_PATH))
        except Exception:
            pass
        (browser or context).close()
    print("Login saved.\n")


# ---------------------------------------------------------------------------
# Task discovery (same logic as export_chats.py)
# ---------------------------------------------------------------------------
def discover_task_links(page, cfg):
    print("Discovering your tasks... (scrolling the task list)")
    include = cfg["selectors"].get("task_link_include_paths", [])
    exclude = cfg["selectors"].get("task_link_exclude_paths", [])

    def is_wanted(href):
        low = href.lower()
        if exclude and any(x.lower() in low for x in exclude):
            return False
        if include:
            return any(inc.lower() in low for inc in include)
        return True

    def scroll_everything():
        page.mouse.wheel(0, 6000)
        page.wait_for_timeout(cfg.get("scroll_pause_ms", 800))
        try:
            page.evaluate(
                """() => {
                    const nodes = document.querySelectorAll('nav, aside, [class*="sidebar"], [class*="Sidebar"], [class*="scroll"]');
                    nodes.forEach(n => { n.scrollTop = n.scrollHeight; });
                }"""
            )
        except Exception:
            pass
        page.wait_for_timeout(300)

    found = {}
    stable_rounds = 0
    for _ in range(cfg.get("max_scroll_rounds", 40)):
        scroll_everything()
        before = len(found)
        for selector in cfg["selectors"]["task_list_links"]:
            try:
                handles = page.query_selector_all(selector)
            except Exception:
                continue
            for h in handles:
                try:
                    href = h.get_attribute("href")
                    if not href:
                        a = h.query_selector("a[href]")
                        href = a.get_attribute("href") if a else None
                    if not href:
                        continue
                    if href.startswith("/"):
                        href = cfg["base_url"].rstrip("/") + href
                    if cfg["base_url"] not in href:
                        continue
                    if not is_wanted(href):
                        continue
                    label = (h.inner_text() or "").strip().split("\n")[0]
                    if href not in found:
                        found[href] = label
                except Exception:
                    continue
        if len(found) == before:
            stable_rounds += 1
            if stable_rounds >= 3 and len(found) > 0:
                break
        else:
            stable_rounds = 0

    links = [{"url": u, "label": lbl} for u, lbl in found.items()]
    print(f"Found {len(links)} task link(s).")
    return links


def resolve_title(page, cfg, url, fallback_title):
    """Resolve a task's title the same way export_chats.py does, so the
    workspace files land in the SAME folder name as the chat export."""
    t_val = None
    for tsel in cfg["selectors"].get("task_title", []):
        try:
            el = page.query_selector(tsel)
            if el:
                t = (el.inner_text() or "").strip()
                if t:
                    t_val = t.split("\n")[0]
                    break
        except Exception:
            continue
    generic = {"ninjatech ai", "superninja", "ninja", ""}
    if (not t_val) or t_val.strip().lower() in generic:
        if fallback_title and fallback_title.strip():
            t_val = fallback_title.strip()
        elif not t_val:
            t_val = page.title() or "untitled"
    if t_val.strip().lower() in generic:
        tail = url.rstrip("/").split("/")[-1][:8]
        t_val = f"chat_{tail}"
    return t_val


def unique_dir(base: Path, name: str) -> Path:
    candidate = base / name
    i = 2
    while candidate.exists():
        candidate = base / f"{name}_{i}"
        i += 1
    return candidate


def match_existing_task_dir(out_base: Path, title_slug: str):
    """If the chat exporter already created a folder for this task, reuse it so
    the workspace files sit next to chat.md/chat.html. Matches title_slug or
    title_slug_N. Returns a Path (existing or newly chosen)."""
    exact = out_base / title_slug
    if exact.exists():
        return exact
    # Look for title_slug_2, _3 ... pick the first if any (best-effort).
    for cand in sorted(out_base.glob(f"{title_slug}_*")):
        if cand.is_dir():
            return cand
    # No existing chat folder -> create a fresh unique one.
    return unique_dir(out_base, title_slug)


# ---------------------------------------------------------------------------
# Workspace panel interaction
#
# The reliable, user-verified flow (from the screenshot) is:
#   1) On the task page, click the FOLDER icon in the top toolbar
#      -> opens the "Workspace Files" panel on the right.
#   2) In that panel's header row (Name / Modified / Size), click the
#      "..." (3 vertical dots) button at the far right.
#   3) A small menu appears with "Download all" (and "Delete all").
#      Click "Download all" -> the app zips the whole workspace (including
#      subdirectories) and triggers a single browser download.
#   4) We capture that download with Playwright and save it straight into the
#      task's folder as workspace.zip (so it does NOT just land in Downloads,
#      and it gets a sensible name).
# ---------------------------------------------------------------------------

# Click the folder icon in the top toolbar to open the Workspace Files panel.
OPEN_WORKSPACE_PANEL_JS = r"""
() => {
    // If the panel is already open, do nothing.
    const already = Array.from(document.querySelectorAll('*')).some(
        el => (el.textContent || '').trim().startsWith('Workspace Files'));
    if (already) return 'already-open';

    // The Workspace-Files folder icon lives in the TOP toolbar (top ~80px of
    // the window, on the right side). Its exact Phosphor "folder-open" path
    // starts 'M216,72H130.67'. A shorter 'M216,72H180.92' is the sidebar
    // "Get Free Credits" gift icon - we must NOT click that. So we require the
    // full 'M216,72H130.67' signature AND a top-toolbar position.
    const EXACT = 'M216,72H130.67';
    const btns = Array.from(document.querySelectorAll('button, [role="button"]'));

    // Pass 1: exact folder-open signature, anywhere.
    for (const b of btns) {
        const p = b.querySelector('svg path');
        const d = (p?.getAttribute('d') || '').replace(/\s/g, '');
        if (d.startsWith(EXACT)) {
            const r = b.getBoundingClientRect();
            // Prefer the top-toolbar instance (near the top of the window).
            if (r.y < 120) { b.click(); return 'folder-icon-top'; }
        }
    }
    // Pass 2: exact signature anywhere (even if not obviously top-bar).
    for (const b of btns) {
        const p = b.querySelector('svg path');
        const d = (p?.getAttribute('d') || '').replace(/\s/g, '');
        if (d.startsWith(EXACT)) { b.click(); return 'folder-icon'; }
    }
    // Pass 3: generic 'M216,72H' but only in the top toolbar (avoid sidebar).
    for (const b of btns) {
        const p = b.querySelector('svg path');
        const d = (p?.getAttribute('d') || '').replace(/\s/g, '');
        if (d.startsWith('M216,72H')) {
            const r = b.getBoundingClientRect();
            if (r.y < 120 && r.x > 300) { b.click(); return 'folder-icon-generic'; }
        }
    }
    // Fallback: aria-label / title.
    const byLabel = btns.find(b => {
        const s = ((b.getAttribute('aria-label') || '') + ' ' +
                   (b.getAttribute('title') || '')).toLowerCase();
        return /workspace|files|folder/.test(s);
    });
    if (byLabel) { byLabel.click(); return 'label'; }
    return '';
}
"""

# Click the "..." (3 dots) in the Workspace Files header. We anchor precisely
# off the "Workspace Files" text node and the "Size" column header so we only
# consider buttons INSIDE the panel header (never the left sidebar's "More"
# dots, which share the same Phosphor dots-three-vertical icon).
# Return the bounding box of the "Global actions" kebab in the Workspace Files
# panel header. This is the button that opens the menu containing "Download
# all" (per-file kebabs are labelled "Row actions"). Playwright then clicks it
# with a REAL mouse click, which Radix menus require to open reliably.
GLOBAL_ACTIONS_BOX_JS = r"""
() => {
    // Locate the Workspace Files panel first, so we only accept a "Global
    // actions" kebab that lives INSIDE it (not some other toolbar button that
    // happens to share the label or sits in the top window bar at y~27).
    const all = Array.from(document.querySelectorAll('*'));
    const wsLabel = all.find(el => {
        let own = '';
        for (const n of el.childNodes) if (n.nodeType === 3) own += n.textContent;
        return own.trim().startsWith('Workspace Files');
    });
    if (!wsLabel) return null;
    let panel = wsLabel;
    for (let i = 0; i < 10 && panel.parentElement; i++) {
        panel = panel.parentElement;
        const t = panel.textContent || '';
        if (/Modified/.test(t) && /Size/.test(t)) break;
    }
    const pr = panel.getBoundingClientRect();

    const insidePanel = (b) => {
        const r = b.getBoundingClientRect();
        const cx = r.x + r.width / 2, cy = r.y + r.height / 2;
        // Must be within the panel's box AND below its very top (the file-list
        // header sits ~40-140px down; y=27 in the window bar is excluded).
        return r.width > 0 && r.height > 0 &&
               cx >= pr.x && cx <= pr.x + pr.width &&
               cy >= pr.y + 30 && cy <= pr.y + pr.height;
    };

    // 1) aria-label="Global actions" INSIDE the panel.
    let btn = Array.from(document.querySelectorAll('button, [role="button"]'))
        .find(b => (b.getAttribute('aria-label') || '').trim().toLowerCase() === 'global actions'
                   && insidePanel(b));

    // 2) Fallback: topmost small dots-kebab inside the panel.
    if (!btn) {
        const isDots = (b) => {
            const d = (b.querySelector('svg path')?.getAttribute('d') || '').replace(/\s/g, '');
            return d.startsWith('M140,128a12') || d.startsWith('M128,96a32');
        };
        btn = Array.from(document.querySelectorAll('button, [role="button"]'))
            .filter(b => b.getBoundingClientRect().width < 60 && insidePanel(b) && isDots(b))
            .sort((a, b) => a.getBoundingClientRect().y - b.getBoundingClientRect().y)[0];
    }

    if (!btn) return null;
    const r = btn.getBoundingClientRect();
    return { x: r.x, y: r.y, w: r.width, h: r.height, panelTop: pr.y };
}
"""

# Return the bounding box of the file-list column-header row (Name/Modified/
# Size) inside the Workspace Files panel, so Playwright can hover it with the
# real mouse to reveal the hover-only "..." control.
HEADER_ROW_BOX_JS = r"""
() => {
    const all = Array.from(document.querySelectorAll('*'));
    const wsLabel = all.find(el => {
        let own = '';
        for (const n of el.childNodes) if (n.nodeType === 3) own += n.textContent;
        return own.trim().startsWith('Workspace Files');
    });
    if (!wsLabel) return null;
    let panel = wsLabel;
    for (let i = 0; i < 10 && panel.parentElement; i++) {
        panel = panel.parentElement;
        const t = panel.textContent || '';
        if (/Modified/.test(t) && /Size/.test(t)) break;
    }
    const headerRow = Array.from(panel.querySelectorAll('*')).find(el => {
        const t = (el.textContent || '');
        const r = el.getBoundingClientRect();
        return /\bName\b/.test(t) && /\bModified\b/.test(t) && /\bSize\b/.test(t)
               && r.height > 0 && r.height < 80 && r.width > 100;
    });
    const el = headerRow || panel;
    const r = el.getBoundingClientRect();
    return { x: r.x, y: r.y, w: r.width, h: r.height };
}
"""

OPEN_HEADER_MENU_JS = r"""
() => {
    // The "..." (Download all) control in the Workspace Files panel is a
    // HOVER-ONLY button: it is not in the DOM until you mouse over the file
    // list's column-header row (Name / Modified / Size). So we must first
    // simulate hovering that row, then click the dots button that appears.

    // Helper: fire a full hover gesture on an element.
    const hover = (el) => {
        if (!el) return;
        const r = el.getBoundingClientRect();
        const cx = r.x + r.width / 2, cy = r.y + r.height / 2;
        for (const type of ['pointerover','pointerenter','mouseover','mouseenter','mousemove']) {
            el.dispatchEvent(new MouseEvent(type, {
                bubbles: true, cancelable: true, view: window,
                clientX: cx, clientY: cy
            }));
        }
    };

    const isDots = (b) => {
        const d = (b.querySelector('svg path')?.getAttribute('d') || '').replace(/\s/g, '');
        // Phosphor dots-three-vertical: big (M128,96a32) OR small (M140,128a12).
        return d.startsWith('M128,96a32') || d.startsWith('M140,128a12') ||
               d.startsWith('M156,128') || d.startsWith('M140,60') ||
               b.querySelectorAll('svg circle').length >= 3;
    };

    // 1) Find the exact element whose OWN text is "Workspace Files".
    const all = Array.from(document.querySelectorAll('*'));
    const wsLabel = all.find(el => {
        let own = '';
        for (const n of el.childNodes) if (n.nodeType === 3) own += n.textContent;
        return own.trim().startsWith('Workspace Files');
    });
    if (!wsLabel) return 'no-label';

    // 2) The panel is an ancestor that also contains the "Size" column header.
    let panel = wsLabel;
    for (let i = 0; i < 10 && panel.parentElement; i++) {
        panel = panel.parentElement;
        const t = panel.textContent || '';
        if (/Modified/.test(t) && /Size/.test(t)) break;
    }
    const pr = panel.getBoundingClientRect();

    // 3) Find the column-header row inside the panel: an element whose own text
    //    mentions Name / Modified / Size. Hover it + a couple of ancestors and
    //    the first file rows, to surface the hover-only "..." button.
    const headerRow = Array.from(panel.querySelectorAll('*')).find(el => {
        const t = (el.textContent || '');
        return /\bName\b/.test(t) && /\bModified\b/.test(t) && /\bSize\b/.test(t)
               && el.getBoundingClientRect().height < 80;
    });
    const hoverTargets = [];
    if (headerRow) {
        hoverTargets.push(headerRow);
        if (headerRow.parentElement) hoverTargets.push(headerRow.parentElement);
        // also hover the row's right edge area children
        for (const c of headerRow.children) hoverTargets.push(c);
    }
    hoverTargets.push(panel);
    for (const t of hoverTargets) hover(t);

    // 4) After hovering, collect all dots-kebab buttons inside the panel.
    //    In the Workspace Files panel these are per-row "..." menus stacked
    //    down the right edge (x ~= panel right - 30). The TOPMOST one sits in
    //    the column-header row and its menu contains "Download all".
    const scanDots = () => {
        return Array.from(document.querySelectorAll('button, [role="button"]')).filter(b => {
            const r = b.getBoundingClientRect();
            if (r.width === 0 || r.height === 0 || r.width >= 60) return false;
            const cx = r.x + r.width / 2, cy = r.y + r.height / 2;
            const inX = cx >= pr.x && cx <= pr.x + pr.width;
            const inY = cy >= pr.y && cy <= pr.y + pr.height;
            return inX && inY && isDots(b);
        }).sort((a, b) => a.getBoundingClientRect().y - b.getBoundingClientRect().y);
    };

    let dots = scanDots();
    if (dots.length) { dots[0].click(); return 'dots-hover-top'; }

    // 5) Fallback: hover the first few file rows to reveal the kebabs, re-scan.
    const rows = Array.from(panel.querySelectorAll('*')).filter(el => {
        const r = el.getBoundingClientRect();
        return r.width > 100 && r.height > 0 && r.height < 60
               && r.y > pr.y && r.y < pr.y + 260;
    });
    for (const c of rows.slice(0, 8)) hover(c);
    dots = scanDots();
    if (dots.length) { dots[0].click(); return 'dots-hover-top2'; }

    return 'no-dots';
}
"""

# Click a specific workspace-panel kebab ("...") by its top-to-bottom index.
# Returns the number of kebabs found (so the caller can iterate). Also re-fires
# hovers so the kebabs stay visible.
CLICK_DOTS_BY_INDEX_JS = r"""
(idx) => {
    const isDots = (b) => {
        const d = (b.querySelector('svg path')?.getAttribute('d') || '').replace(/\s/g, '');
        return d.startsWith('M128,96a32') || d.startsWith('M140,128a12') ||
               d.startsWith('M156,128') || d.startsWith('M140,60') ||
               b.querySelectorAll('svg circle').length >= 3;
    };
    const all = Array.from(document.querySelectorAll('*'));
    const wsLabel = all.find(el => {
        let own = '';
        for (const n of el.childNodes) if (n.nodeType === 3) own += n.textContent;
        return own.trim().startsWith('Workspace Files');
    });
    if (!wsLabel) return { count: 0, clicked: false };
    let panel = wsLabel;
    for (let i = 0; i < 10 && panel.parentElement; i++) {
        panel = panel.parentElement;
        const t = panel.textContent || '';
        if (/Modified/.test(t) && /Size/.test(t)) break;
    }
    const pr = panel.getBoundingClientRect();
    const dots = Array.from(document.querySelectorAll('button, [role="button"]')).filter(b => {
        const r = b.getBoundingClientRect();
        if (r.width === 0 || r.height === 0 || r.width >= 60) return false;
        const cx = r.x + r.width / 2, cy = r.y + r.height / 2;
        return cx >= pr.x && cx <= pr.x + pr.width &&
               cy >= pr.y && cy <= pr.y + pr.height && isDots(b);
    }).sort((a, b) => a.getBoundingClientRect().y - b.getBoundingClientRect().y);
    if (idx < 0 || idx >= dots.length) return { count: dots.length, clicked: false };
    dots[idx].click();
    return { count: dots.length, clicked: true };
}
"""

# Return True if a "Download all" item is currently visible anywhere.
HAS_DOWNLOAD_ALL_JS = r"""
() => {
    const norm = s => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();
    return Array.from(document.querySelectorAll(
        '[role="menuitem"], [role="menu"] *, [data-radix-collection-item], button, a, li, div, span'))
        .some(x => { const t = norm(x.textContent);
                     return t === 'download all' || (t.startsWith('download all') && t.length <= 16); });
}
"""

# Click the "Download all" menu item that appears after the 3-dots menu opens.
# SuperNinja renders this menu in a portal at the end of <body>, so we search
# the whole document but match the exact label.
CLICK_DOWNLOAD_ALL_JS = r"""
() => {
    const norm = s => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();
    // Look at leaf-ish clickable elements so we don't match a big container
    // that merely CONTAINS the words.
    const cands = Array.from(document.querySelectorAll(
        '[role="menuitem"], [role="menu"] *, [data-radix-collection-item], button, a, li, div, span'));
    // Exact "download all" first.
    let el = cands.find(x => norm(x.textContent) === 'download all');
    // Then a short element that starts with it (icon + label).
    if (!el) el = cands.find(x => {
        const t = norm(x.textContent);
        return t.startsWith('download all') && t.length <= 16;
    });
    if (el) {
        (el.closest('[role="menuitem"], button, a, li') || el).click();
        return true;
    }
    return false;
}
"""


def download_all_workspace_files(page, cfg, task_dir: Path):
    """Open the workspace panel, click the 3-dots header menu, and click
    'Download all' - capturing the resulting zip into the task folder.

    Returns (num_downloaded_files_or_archives, notes_list).
    """
    notes = []
    pause = cfg.get("scroll_pause_ms", 700)

    # 1) Open the Workspace Files panel via the folder icon. The page may still
    #    be loading, so retry a few times, waiting for the panel to appear.
    def panel_is_open():
        try:
            return bool(page.evaluate(
                "() => Array.from(document.querySelectorAll('*'))"
                ".some(el => (el.textContent||'').trim().startsWith('Workspace Files'))"))
        except Exception:
            return False

    how = ""
    for _try in range(6):
        if panel_is_open():
            how = how or "already-open"
            break
        try:
            how = page.evaluate(OPEN_WORKSPACE_PANEL_JS) or ""
        except Exception:
            how = ""
        page.wait_for_timeout(1200)
        if panel_is_open():
            break
    if panel_is_open():
        print(f"      [ws] workspace panel open ({how or 'ok'}).")
    else:
        print("      [ws] could not open the Workspace Files panel; skipping.")
        notes.append("Workspace Files panel did not open (folder icon not found).")
        return 0, notes
    page.wait_for_timeout(max(pause, 1200))

    # 1b) Wait for the file list (and the 'Global actions' kebab) to render.
    #     Hover the panel each round so the hover-only kebab appears. This
    #     prevents clicking before the list has loaded (which produced a bogus
    #     y=27 coordinate in the top window bar during fast full runs).
    def global_actions_ready():
        try:
            gb = page.evaluate(GLOBAL_ACTIONS_BOX_JS)
            return bool(gb and gb.get("w", 0) > 0 and gb.get("y", 0) > 60)
        except Exception:
            return False

    # Wait until we are SURE the panel is fully rendered (the 'Global actions'
    # kebab exists at a real coordinate) before touching anything. Large
    # workspaces / slow connections can take a while to populate the file list,
    # so this wait is generous and configurable via ws_panel_ready_rounds /
    # ws_panel_ready_pause_ms (default ~30s total).
    ready_rounds = cfg.get("ws_panel_ready_rounds", 30)
    ready_pause = cfg.get("ws_panel_ready_pause_ms", 1000)
    panel_ready = False
    for _w in range(ready_rounds):
        # nudge hover across the panel so hover-only controls render
        try:
            hb = page.evaluate(HEADER_ROW_BOX_JS)
            if hb and hb.get("w", 0) > 0:
                page.mouse.move(hb["x"] + hb["w"] / 2, hb["y"] + hb["h"] / 2)
        except Exception:
            pass
        if global_actions_ready():
            panel_ready = True
            break
        page.wait_for_timeout(ready_pause)

    if panel_ready:
        print("      [ws] file list rendered; 'Global actions' kebab ready.")
    else:
        print("      [ws] warning: 'Global actions' kebab not confirmed after "
              f"{int(ready_rounds * ready_pause / 1000)}s; will still try, "
              "then fall back to kebab probe.")
        notes.append("Panel ready check did not confirm Global actions kebab in time.")

    # 2) Physically hover the file-list column-header row with the real mouse.
    #    The "..." (Download all) control only appears on hover, and React
    #    hover states respond far more reliably to a real pointer move than to
    #    synthetic events. We locate the header-row box in JS, then move the
    #    Playwright mouse across it.
    try:
        box = page.evaluate(HEADER_ROW_BOX_JS)
    except Exception:
        box = None
    if box and box.get("w", 0) > 0:
        try:
            cx = box["x"] + box["w"] / 2
            cy = box["y"] + box["h"] / 2
            # Move onto the row, then toward its right edge where the "..." sits.
            page.mouse.move(cx, cy)
            page.wait_for_timeout(120)
            page.mouse.move(box["x"] + box["w"] - 12, cy)
            page.wait_for_timeout(250)
        except Exception:
            pass

    # 3) Reveal the header kebab by hovering the file-list, then open the
    #    "Global actions" (...) menu with a REAL mouse click (Radix menus need
    #    a real pointer event to open), and click "Download all".
    #    First hover the file area so the "Global actions" kebab is rendered.
    try:
        hbox = page.evaluate(HEADER_ROW_BOX_JS)
    except Exception:
        hbox = None
    if hbox and hbox.get("w", 0) > 0:
        try:
            page.mouse.move(hbox["x"] + hbox["w"] / 2, hbox["y"] + hbox["h"] / 2)
            page.wait_for_timeout(150)
        except Exception:
            pass
    try:
        page.evaluate(OPEN_HEADER_MENU_JS)  # synthetic hovers as extra nudge
    except Exception:
        pass
    page.wait_for_timeout(300)

    dest = None
    save_timeout_s = cfg.get("ws_save_timeout_ms", 180000) / 1000.0

    def bounded_save(dl, target: Path):
        """Save a download but never hang forever. Returns True on success.

        download.save_as() blocks until the file finishes; for a very large or
        stalled zip that can hang the whole run, so we run it in a worker thread
        with a hard timeout and give up (logging) if it overruns.
        """
        import threading
        result = {"ok": False, "err": None}

        def _worker():
            try:
                dl.save_as(str(target))
                result["ok"] = True
            except Exception as e:
                result["err"] = e

        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        t.join(save_timeout_s)
        if t.is_alive():
            result["err"] = f"save timed out after {int(save_timeout_s)}s"
        return result["ok"], result["err"]

    def try_download_from_menu():
        """After a menu is open, if it has 'Download all', click it and capture."""
        has_da = False
        try:
            has_da = bool(page.evaluate(HAS_DOWNLOAD_ALL_JS))
        except Exception:
            has_da = False
        if not has_da:
            return None
        with page.expect_download(
                timeout=cfg.get("ws_download_timeout_ms", 120000)) as dl_info:
            if not page.evaluate(CLICK_DOWNLOAD_ALL_JS):
                # Try a real click on the "Download all" text as a fallback.
                try:
                    page.get_by_text("Download all", exact=False).first.click(timeout=3000)
                except Exception:
                    raise RuntimeError("'Download all' present but click missed")
        return dl_info.value

    # 3a) Preferred path: real-click the "Global actions" kebab.
    try:
        gbox = page.evaluate(GLOBAL_ACTIONS_BOX_JS)
    except Exception:
        gbox = None

    if gbox and gbox.get("w", 0) > 0 and gbox.get("y", 0) > 60:
        for attempt in range(2):
            try:
                # Re-read the kebab box just before clicking so we always use a
                # fresh, valid coordinate (the panel may have re-laid-out while
                # a large file list finished rendering).
                gbox = page.evaluate(GLOBAL_ACTIONS_BOX_JS)
                if not (gbox and gbox.get("w", 0) > 0 and gbox.get("y", 0) > 60):
                    print("      [ws] kebab coordinate not valid yet; "
                          "waiting before click...")
                    page.wait_for_timeout(1500)
                    continue
                gx = gbox["x"] + gbox["w"] / 2
                gy = gbox["y"] + gbox["h"] / 2
                print(f"      [ws] clicking 'Global actions' kebab at "
                      f"({int(gx)},{int(gy)})...")
                page.mouse.move(gx, gy)
                page.wait_for_timeout(120)
                page.mouse.click(gx, gy)
                page.wait_for_timeout(500)
                dl = try_download_from_menu()
                if dl:
                    suggested = dl.suggested_filename or "workspace.zip"
                    ext = Path(suggested).suffix.lower() or ".zip"
                    dest = task_dir / f"workspace{ext}"
                    ok, err = bounded_save(dl, dest)
                    if ok:
                        size = dest.stat().st_size if dest.exists() else 0
                        print(f"      [ws] saved {dest.name} ({size} bytes).")
                        return 1, notes
                    # Save stalled/timed out: log and fall through to fallback.
                    notes.append(f"download save failed/stalled: {err}")
                    print(f"      [ws] download save failed/stalled: {err}")
                    dest = None
            except Exception as e:
                notes.append(f"Global-actions attempt {attempt} failed: {e}")
                print(f"      [ws] global-actions attempt {attempt} failed: {e}")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            page.wait_for_timeout(200)
    else:
        print("      [ws] 'Global actions' kebab not found; trying kebab probe...")

    # 3b) Fallback: probe kebabs via JS click (some builds respond to it).
    if not dest:
        try:
            info = page.evaluate(CLICK_DOTS_BY_INDEX_JS, -1)
            n_dots = int(info.get("count", 0)) if isinstance(info, dict) else 0
        except Exception:
            n_dots = 0
        print(f"      [ws] probing {n_dots} kebab(s) for 'Download all'...")
        for idx in range(min(n_dots, 8)):
            try:
                page.evaluate(OPEN_HEADER_MENU_JS)
                page.wait_for_timeout(120)
                page.evaluate(CLICK_DOTS_BY_INDEX_JS, idx)
                page.wait_for_timeout(400)
                dl = try_download_from_menu()
                if dl:
                    suggested = dl.suggested_filename or "workspace.zip"
                    ext = Path(suggested).suffix.lower() or ".zip"
                    dest = task_dir / f"workspace{ext}"
                    ok, err = bounded_save(dl, dest)
                    if ok:
                        size = dest.stat().st_size if dest.exists() else 0
                        print(f"      [ws] saved {dest.name} ({size} bytes) via kebab #{idx}.")
                        return 1, notes
                    notes.append(f"kebab #{idx} save failed/stalled: {err}")
                    print(f"      [ws] kebab #{idx} save failed/stalled: {err}")
                    dest = None
            except Exception as e:
                notes.append(f"kebab #{idx} failed: {e}")
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
            page.wait_for_timeout(120)

    if not dest:
        notes.append("Could not open a 'Download all' menu (Global actions kebab).")
        print("      [ws] could not open a 'Download all' menu.")

    # Fallback note: if the archive download didn't fire, the file may have gone
    # to the browser's default Downloads folder instead (user said that's OK).
    notes.append("If nothing was saved here, check your browser's Downloads folder - "
                 "the 'Download all' may have saved there. Run DIAGNOSE_WORKSPACE "
                 "to inspect the menu markup so it can be captured directly.")
    return 0, notes


# ---------------------------------------------------------------------------
# Per-task driver
# ---------------------------------------------------------------------------
def process_task(page, cfg, url, fallback_title, out_base: Path):
    page.goto(url, wait_until="domcontentloaded")
    # The SuperNinja SPA needs time to render its toolbar + workspace after
    # navigation. Wait for network to settle, then a fixed settle pause.
    try:
        page.wait_for_load_state("networkidle", timeout=15000)
    except Exception:
        pass
    page.wait_for_timeout(cfg.get("ws_task_settle_ms", 3500))
    title = resolve_title(page, cfg, url, fallback_title)
    title_slug = slugify(title)
    task_dir = match_existing_task_dir(out_base, title_slug)
    task_dir.mkdir(parents=True, exist_ok=True)

    n, notes = download_all_workspace_files(page, cfg, task_dir)

    # Optionally unzip the downloaded archive so files (and subdirectories) are
    # directly browsable inside the task folder under workspace/.
    if n and cfg.get("ws_unzip_archive", True):
        try:
            import zipfile
            arc = task_dir / "workspace.zip"
            if not arc.exists():
                # find any workspace.* archive
                for cand in task_dir.glob("workspace.*"):
                    if cand.suffix.lower() in (".zip",):
                        arc = cand
                        break
            if arc.exists() and zipfile.is_zipfile(arc):
                ws_dir = task_dir / "workspace"
                ws_dir.mkdir(exist_ok=True)
                with zipfile.ZipFile(arc) as zf:
                    zf.extractall(ws_dir)
                print(f"      [ws] unzipped into {ws_dir.name}/ "
                      f"({len(list(ws_dir.rglob('*')))} entries).")
        except Exception as e:
            notes.append(f"Unzip failed (archive kept): {e}")
            print(f"      [ws] unzip failed: {e}")

    # Write a small log per task.
    with open(task_dir / "workspace_download.log", "w", encoding="utf-8") as f:
        f.write(f"Task: {title}\nURL: {url}\n")
        f.write(f"Archives downloaded: {n}\n\n")
        if notes:
            f.write("Notes:\n" + "\n".join(f"  - {x}" for x in notes) + "\n")
    return title, n, notes, task_dir


def main():
    print("=" * 70)
    print(f"  SuperNinja Workspace Downloader  {DOWNLOADER_VERSION}")
    print("=" * 70)

    parser = argparse.ArgumentParser(description="Download SuperNinja workspace files per task.")
    parser.add_argument("--login", action="store_true", help="Force a fresh manual login.")
    parser.add_argument("--limit", type=int, default=0, help="Only process the first N tasks.")
    parser.add_argument("--start", type=int, default=1, help="Start at this task number (1-based).")
    parser.add_argument("--end", type=int, default=0, help="End at this task number (inclusive).")
    args = parser.parse_args()

    cfg = load_config()

    if args.login:
        do_manual_login(cfg)
        return

    out_base = HERE / cfg.get("output_dir", "SuperNinja_Export")
    out_base.mkdir(parents=True, exist_ok=True)
    summary = []

    with sync_playwright() as p:
        cdp = cfg.get("connect_mode") == "cdp"
        browser, context = launch_browser(p, cfg, headless=False)

        # Reuse an existing page (your real Chrome tab) if possible.
        page = None
        if context.pages:
            for pg in context.pages:
                try:
                    if "myninja.ai" in (pg.url or ""):
                        page = pg
                        break
                except Exception:
                    continue
            if page is None:
                page = context.pages[0]
        else:
            page = context.new_page()

        try:
            if "myninja.ai" not in (page.url or ""):
                page.goto(cfg["base_url"], wait_until="domcontentloaded")
        except Exception:
            page.goto(cfg["base_url"], wait_until="domcontentloaded")

        for attempt in range(4):
            page.wait_for_timeout(2500)
            try:
                body_text = (page.inner_text("body") or "").strip()
            except Exception:
                body_text = ""
            link_count = 0
            try:
                link_count = len(page.query_selector_all("a"))
            except Exception:
                pass
            if len(body_text) > 40 or link_count > 3:
                break
            print(f"  Page looks blank (attempt {attempt+1}/4) - reloading...")
            try:
                page.reload(wait_until="domcontentloaded")
            except Exception:
                page.goto(cfg["base_url"], wait_until="domcontentloaded")

        links = discover_task_links(page, cfg)
        if not links:
            print("\nNo task links found. Try:  python download_workspace.py --login")
            if not cdp:
                (browser or context).close()
            return

        total_found = len(links)
        print(f"Discovered {total_found} task(s) total.")

        start_i = max(1, args.start)
        if args.end and args.end > 0:
            end_i = min(args.end, total_found)
        elif args.limit and args.limit > 0:
            end_i = min(start_i + args.limit - 1, total_found)
        else:
            end_i = total_found

        if start_i > total_found:
            print(f"Start index {start_i} is beyond the {total_found} tasks found. Nothing to do.")
            if not cdp:
                (browser or context).close()
            return

        windowed = [(n, links[n - 1]) for n in range(start_i, end_i + 1)]
        print(f"Downloading workspace files for tasks {start_i} through {end_i} "
              f"({len(windowed)} of {total_found}).")

        skip_existing = cfg.get("ws_skip_existing", True)
        for idx, link in windowed:
            print(f"[{idx}/{total_found}] Task: {link['label'] or link['url']}")

            # Optional: skip tasks that already have a populated workspace/ dir.
            if skip_existing:
                slug = slugify(link.get("label") or link["url"])
                existing = match_existing_task_dir(out_base, slug)
                ws = existing / "workspace"
                if ws.exists() and any(ws.iterdir()):
                    print(f"      -> already downloaded ({existing.name}/workspace/); skipping.")
                    summary.append({
                        "index": idx, "title": link.get("label"), "url": link["url"],
                        "archives_downloaded": 0, "folder": str(existing.relative_to(HERE)),
                        "skipped": True,
                    })
                    continue

            n = 0
            folder = out_base
            title = link.get("label")
            # Try up to 2 attempts (a fresh reload fixes most transient
            # page-state / hover-timing failures seen during fast full runs).
            for attempt in range(cfg.get("ws_task_retries", 2)):
                try:
                    title, n, notes, folder = process_task(
                        page, cfg, link["url"], link.get("label"), out_base
                    )
                    if n:
                        break
                    if attempt == 0:
                        print("      -> nothing captured; retrying this task once...")
                        page.wait_for_timeout(1500)
                except PWTimeout:
                    print(f"      !! Timed out on {link['url']} (attempt {attempt+1}).")
                except Exception as e:
                    print(f"      !! Error on {link['url']} (attempt {attempt+1}): {e}")
                    page.wait_for_timeout(1000)

            summary.append({
                "index": idx, "title": title, "url": link["url"],
                "archives_downloaded": n,
                "folder": str(folder.relative_to(HERE)) if hasattr(folder, "relative_to") else str(folder),
                "incomplete": (not n),
            })
            if n:
                print(f"      -> saved workspace archive into {folder.name}/")
            else:
                print(f"      -> FAILED after {cfg.get('ws_task_retries', 2)} attempt(s); "
                      f"marked incomplete, moving on to next task.")

        if not cdp:
            (browser or context).close()

    with open(out_base / "workspace_manifest.json", "w", encoding="utf-8") as f:
        json.dump({"downloaded_at": datetime.now().isoformat(), "tasks": summary},
                  f, ensure_ascii=False, indent=2)

    print("\n" + "=" * 70)
    total_files = sum(s["archives_downloaded"] for s in summary)
    skipped = [s for s in summary if s.get("skipped")]
    incomplete = [s for s in summary
                  if s.get("incomplete") and not s.get("skipped")]
    completed = [s for s in summary
                 if s["archives_downloaded"] and not s.get("skipped")]

    print(f"DONE. Downloaded {total_files} workspace archive(s).")
    print(f"  Completed : {len(completed)}")
    print(f"  Skipped   : {len(skipped)} (already had workspace/)")
    print(f"  INCOMPLETE: {len(incomplete)}")
    print(f"Output folder: {out_base}")

    # Report every task that did NOT complete after its retries, and write a
    # standalone file so you can re-run just those later.
    if incomplete:
        print("\n" + "-" * 70)
        print("TASKS NOT COMPLETED (failed after retries - re-run these):")
        print("-" * 70)
        lines = []
        for s in incomplete:
            line = f"[{s['index']}] {s.get('title') or '(untitled)'}\n      {s['url']}"
            print("  " + line)
            lines.append(line)
        report = out_base / "INCOMPLETE_TASKS.txt"
        with open(report, "w", encoding="utf-8") as f:
            f.write(f"Incomplete tasks as of {datetime.now().isoformat()}\n")
            f.write(f"({len(incomplete)} task(s) failed after "
                    f"{cfg.get('ws_task_retries', 2)} attempt(s) each)\n\n")
            f.write("\n\n".join(lines) + "\n")
        print(f"\nWrote list of incomplete tasks to: {report}")
    else:
        print("\nAll processed tasks completed successfully.")
    print("=" * 70)


if __name__ == "__main__":
    main()
