@echo off
REM ============================================================
REM  SuperNinja Chat Exporter - DIAGNOSE
REM  Run this WITH Chrome open (0_START_CHROME.bat) and logged in,
REM  showing your list of tasks. It figures out the correct
REM  selectors and writes diagnostics.txt for us to review.
REM ============================================================
echo.
echo === SuperNinja Exporter: Diagnostics ===
echo.
echo Make sure:
echo   1. You ran 0_START_CHROME.bat and are LOGGED IN.
echo   2. You can SEE YOUR LIST OF TASKS in that Chrome window.
echo   3. That Chrome window is still OPEN.
echo.
pause

if not exist venv\Scripts\activate.bat (
    echo ERROR: Run 1_SETUP.bat first.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
python DIAGNOSE.py

echo.
echo Done. Two files were created in this folder:
echo    diagnostics.txt   and   page_dump.html
echo Please send  diagnostics.txt  back so we can set the right selectors.
echo.
pause
