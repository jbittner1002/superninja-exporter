#!/usr/bin/env python3
"""
Finds the "jump to top" button on the CURRENT open chat page.

HOW TO USE:
  1. Keep the Chrome you opened with 0_START_CHROME.bat running.
  2. Open the big "Single Mic Unit Setup" chat (or any chat) and scroll down a
     bit so the floating up-arrow button is visible.
  3. Run this script (double-click FIND_TOP_BUTTON.bat).
  4. Send me the printed output (also saved to top_button.txt).
"""

import json
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("Playwright not installed. Run 1_SETUP.bat first.")
    raise SystemExit(1)

HERE = Path(__file__).resolve().parent
CFG = json.load(open(HERE / "config.json", encoding="utf-8"))
PORT = CFG.get("cdp_port", 9222)
OUT = HERE / "top_button.txt"

DUMP_JS = r"""
() => {
    function info(b) {
        const r = b.getBoundingClientRect();
        const st = window.getComputedStyle(b);
        const svg = b.querySelector('svg');
        let svgHtml = '';
        if (svg) { svgHtml = svg.outerHTML.slice(0, 400); }
        return {
            tag: b.tagName,
            cls: (typeof b.className === 'string' ? b.className : ''),
            aria: b.getAttribute('aria-label') || '',
            title: b.getAttribute('title') || '',
            dataTestId: b.getAttribute('data-testid') || '',
            pos: st.position,
            borderRadius: st.borderRadius,
            x: Math.round(r.left), y: Math.round(r.top),
            w: Math.round(r.width), h: Math.round(r.height),
            hasSvg: !!svg,
            svg: svgHtml,
            outer: b.outerHTML.slice(0, 300)
        };
    }
    // Collect ALL buttons + role=button + anchors that are small and roundish.
    const all = Array.from(document.querySelectorAll('button, [role="button"], a'));
    const results = [];
    for (const b of all) {
        const r = b.getBoundingClientRect();
        if (r.width === 0 || r.height === 0) continue;
        // Small-ish elements (candidate floating buttons) OR anything with an svg
        // in the lower-right quadrant.
        const smallRound = (r.width <= 80 && r.height <= 80 &&
                            Math.abs(r.width - r.height) <= 20);
        const lowerRight = r.left > window.innerWidth * 0.5 &&
                           r.top > window.innerHeight * 0.3;
        if (smallRound || (b.querySelector('svg') && lowerRight)) {
            results.push(info(b));
        }
    }
    return {
        viewport: {w: window.innerWidth, h: window.innerHeight},
        count: results.length,
        buttons: results
    };
}
"""


def main():
    lines = []

    def log(s=""):
        print(s)
        lines.append(str(s))

    with sync_playwright() as p:
        try:
            browser = p.chromium.connect_over_cdp(f"http://localhost:{PORT}")
        except Exception as e:
            log(f"ERROR: could not connect to Chrome on port {PORT}: {e}")
            log("Make sure you started Chrome with 0_START_CHROME.bat.")
            OUT.write_text("\n".join(lines), encoding="utf-8")
            return

        ctx = browser.contexts[0] if browser.contexts else None
        if not ctx or not ctx.pages:
            log("No open pages found.")
            OUT.write_text("\n".join(lines), encoding="utf-8")
            return

        # Pick the page that looks like a chat (/agents/ or /projects/).
        page = None
        for pg in ctx.pages:
            if "/agents/" in pg.url or "/projects/" in pg.url:
                page = pg
                break
        if page is None:
            page = ctx.pages[-1]

        log(f"PAGE URL: {page.url}")
        try:
            data = page.evaluate(DUMP_JS)
        except Exception as e:
            log(f"ERROR evaluating page: {e}")
            OUT.write_text("\n".join(lines), encoding="utf-8")
            return

        log(f"VIEWPORT: {data['viewport']}")
        log(f"CANDIDATE BUTTONS: {data['count']}")
        log("=" * 70)
        for i, b in enumerate(data["buttons"]):
            log(f"\n--- CANDIDATE #{i} ---")
            log(f"  tag={b['tag']}  pos={b['pos']}  radius={b['borderRadius']}")
            log(f"  size={b['w']}x{b['h']}  at=({b['x']},{b['y']})  hasSvg={b['hasSvg']}")
            if b["aria"]:
                log(f"  aria-label={b['aria']!r}")
            if b["title"]:
                log(f"  title={b['title']!r}")
            if b["dataTestId"]:
                log(f"  data-testid={b['dataTestId']!r}")
            log(f"  class={b['cls']!r}")
            if b["svg"]:
                log(f"  svg={b['svg']}")
            log(f"  outerHTML={b['outer']}")

    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"\nSaved to {OUT}")


if __name__ == "__main__":
    main()
