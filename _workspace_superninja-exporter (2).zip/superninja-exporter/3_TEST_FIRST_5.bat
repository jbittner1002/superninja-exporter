@echo off
REM ============================================================
REM  SuperNinja Chat Exporter - TEST RUN (first 5 tasks only)
REM ============================================================
echo.
echo === SuperNinja Exporter: TEST (first 5 tasks) ===
echo.
echo BEFORE running this:
echo   1. Double-click  0_START_CHROME.bat
echo   2. In the Chrome window that opens, log into SuperNinja
echo      and make sure you can see your tasks.
echo   3. Leave that Chrome window OPEN, then continue here.
echo.
pause

if not exist venv\Scripts\activate.bat (
    echo ERROR: Setup has not been run yet.
    echo Please double-click  1_SETUP.bat  first.
    echo.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
python export_chats.py --limit 5

echo.
echo Test finished. Check the SuperNinja_Export folder.
echo If it looks good, run  2_RUN.bat  for a full export.
echo.
pause
