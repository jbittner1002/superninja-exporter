@echo off
REM ============================================================
REM  SuperNinja Workspace Downloader - RUN (all tasks)
REM  Downloads every workspace file (incl. subdirectories) for
REM  each task into that task's folder. Lets you choose which
REM  task number to START from (and END at).
REM ============================================================
echo.
echo === Workspace Downloader: Full Run ===
echo.
echo BEFORE running this:
echo   1. Double-click  0_START_CHROME.bat
echo   2. Log into SuperNinja in the Chrome window that opens.
echo   3. Leave that Chrome window OPEN, then continue here.
echo.
pause

if not exist venv\Scripts\activate.bat (
    echo ERROR: Setup has not been run yet.
    echo Please double-click  1_SETUP.bat  first.
    echo.
    pause
    exit /b 1
)

echo.
echo -----------------------------------------------------------
echo  Which task number do you want to START from?
echo    - Press ENTER to start at 1 (the beginning).
echo    - Type 6 to skip the first 5 (already tested), etc.
echo -----------------------------------------------------------
set "START=1"
set /p START=Start at task number [1]: 
if "%START%"=="" set "START=1"

echo.
echo  Which task number do you want to END at?
echo    - Press ENTER to go all the way to the last task.
echo    - Or type a number to stop there (inclusive).
echo -----------------------------------------------------------
set "ENDNUM="
set /p ENDNUM=End at task number [all]: 

call venv\Scripts\activate.bat

if "%ENDNUM%"=="" (
    echo.
    echo Downloading workspace files from task %START% to the end...
    python download_workspace.py --start %START%
) else (
    echo.
    echo Downloading workspace files from task %START% to task %ENDNUM%...
    python download_workspace.py --start %START% --end %ENDNUM%
)

echo.
echo Finished. Each task folder in SuperNinja_Export now has a  workspace\
echo subfolder with its downloaded files.
echo.
pause
